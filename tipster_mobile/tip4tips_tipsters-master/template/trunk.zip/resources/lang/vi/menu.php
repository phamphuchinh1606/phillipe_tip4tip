<?php

return [
    'product' => 'Danh Sach San Phan',
    'product.create' => 'Them San Pham',

];
