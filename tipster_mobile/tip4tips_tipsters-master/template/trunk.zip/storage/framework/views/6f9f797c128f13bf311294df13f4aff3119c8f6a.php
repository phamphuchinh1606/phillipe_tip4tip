<?php $__env->startSection('title', 'List of Assignments'); ?>
<?php $__env->startSection('javascript'); ?>
    <script src="<?php echo e(asset('js/admin/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/admin/dataTables.bootstrap.min.js')); ?>"></script>
    <script>
      $(function () {
        $('#viewList').DataTable({
          'paging'      : true,
          'lengthChange': false,
          'searching'   : true,
          'ordering'    : true,
          'info'        : true,
          'autoWidth'   : true
        })
      })
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="box box-list">
        <div class="box-header">
            <h3 class="box-title">List of Assignments</h3>
            <?php if($createAction == true): ?><a href="<?php echo e(route('assignments.create')); ?>" class="btn btn-md btn-primary pull-right"><i class="fa fa-plus"></i> New Assignment</a><?php endif; ?>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
            <?php if(\Session::has('success')): ?>
                <div class="alert alert-success clearfix">
                    <p><?php echo e(\Session::get('success')); ?></p>
                </div><br />
            <?php endif; ?>
            <table id="viewList" class="table table-bordered table-striped">
                <thead>
                <tr>
                    <th>No.</th>
                    <th>Consultant</th>
                    <th>Lead</th>
                    <th>Assigner</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php $i= 0; ?>
                <?php $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $i++ ?>
                <tr>
                    <td><?php echo $i?></td>
                    <td><?php echo e(App\User::getUserByID($assignment->consultant_id)->username); ?></td>
                    <td><?php echo e(App\Model\Lead::getLeadByID($assignment->lead_id)->fullname); ?></td>
                    <td><?php echo e(App\User::getUserByID($assignment->create_by)->username); ?></td>
                    <td style="width: 150px"><?php echo e($assignment->created_at); ?></td>
                    <td class="actions">

                        <?php if($editAction == true): ?><a href="<?php echo e(route('assignments.edit', $assignment->id)); ?>" class="btn btn-xs btn-info" title="Edit"><i class="fa fa-pencil"></i></a><?php endif; ?>
                        <?php if($deleteAction == true): ?><form action="<?php echo e(route('assignments.destroy', $assignment->id)); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <input name="_method" type="hidden" value="DELETE">
                            <button class="btn btn-xs btn-danger" type="submit"><i class="fa fa-trash"></i></button>
                        </form><?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
                <tfoot>
                <tr>
                    <th>No.</th>
                    <th>Consultant</th>
                    <th>Lead</th>
                    <th>Assignment</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
                </tfoot>
            </table>
        </div>
        <!-- /.box-body -->
    </div>
    <!-- /.box -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>