<h1><?php echo e($title); ?></h1>

<p>Thank you</p>