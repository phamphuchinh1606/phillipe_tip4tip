<?php use App\Common\Common;?>

<?php $__env->startSection('title', 'List of activities'); ?>
<?php $__env->startSection('javascript'); ?>
    <script src="<?php echo e(asset('js/admin/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/admin/dataTables.bootstrap.min.js')); ?>"></script>
    <script>
      $(function () {
        $('#viewList').DataTable({
          'paging'      : true,
          'lengthChange': false,
          'searching'   : true,
          'ordering'    : true,
          'info'        : true,
          'autoWidth'   : true
        })
      })
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="box box-list">
        <div class="box-header clearfix">
            <h3 class="box-title">Log Activities</h3>
        </div>

        <!-- /.box-header -->
        <div class="box-body">
            <?php if(\Session::has('success')): ?>
                <div class="alert alert-success clearfix">
                    <p><?php echo e(\Session::get('success')); ?></p>
                </div><br />
            <?php endif; ?>
            <div class="table-responsive">
                <table id="viewList" class="table table-striped">
                    <thead>
                    <tr>
                        <th>User</th>
                        <th>Affected object</th>
                        <th>Action</th>
                        <th>Description</th>
                        <th>Create at</th>
                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $logActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logActivity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($logActivity->user_name); ?></td>
                            <td><?php echo e($logActivity->affected_object); ?></td>
                            <td><?php echo e($logActivity->action); ?></td>
                            <td><?php echo e($logActivity->description); ?></td>
                            <td><?php echo e(Common::dateFormat($logActivity->created_at)); ?></td>
                            <td class="actions text-center">
                                <form action="<?php echo e(route('activities.destroy', $logActivity->id)); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <input name="_method" type="hidden" value="DELETE">
                                    <button class="btn btn-xs btn-danger" type="submit"><i class="fa fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                    <tr>
                        <th>User</th>
                        <th>Affected object</th>
                        <th>Action</th>
                        <th>Description</th>
                        <th>Create at</th>
                        <th>Actions</th>
                    </tr>
                    </tfoot>
                </table>
            </div>
        </div>
        <!-- /.box-body -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>