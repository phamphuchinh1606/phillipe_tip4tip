<?php use \App\Model\Role;?>

<?php $__env->startSection('title', 'List of Message Templates'); ?>
<?php $__env->startSection('javascript'); ?>
    <script src="<?php echo e(asset('js/admin/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/admin/dataTables.bootstrap.min.js')); ?>"></script>
    <script>
      $(function () {
        $('#viewList').DataTable({
          'paging'      : true,
          'lengthChange': false,
          'searching'   : true,
          'ordering'    : true,
          'info'        : true,
          'autoWidth'   : true,
          'order': [],
          'columnDefs': [ { orderable: false, targets: [0]}]
        })
      })
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body.breadcrumbs'); ?>
    <?php echo e(Breadcrumbs::render('messagetemplates')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="box box-list">
        <div class="box-header">
            <h3 class="box-title"><?php echo $__env->yieldContent('title'); ?></h3>
            <?php if($createAction == true): ?><a href="<?php echo e(route('messagetemplates.create')); ?>" class="btn btn-md btn-primary pull-right"><i class="fa fa-plus"></i> New Message Template</a><?php endif; ?>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
            <?php if(\Session::has('success')): ?>
                <div class="alert alert-success clearfix">
                    <p><?php echo e(\Session::get('success')); ?></p>
                </div><br />
            <?php endif; ?>
            <div class="table-responsive">
                <table id="viewList" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <th>No.</th>
                        <th>Message ID</th>
                        <th>Subject VN</th>
                        <th>Subject EN</th>
                        <th>Content VN</th>
                        <th>Content EN</th>
                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $i= 0; ?>
                    <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i++ ?>
                        <tr>
                            <td><?php echo $i?></td>
                            <td><?php echo e($template->message_id); ?></td>
                            <td><?php echo e($template->subject_vn); ?></td>
                            <td><?php echo e($template->subject_en); ?></td>
                            <td><?php echo e($template->content_vn); ?></td>
                            <td><?php echo e($template->content_en); ?></td>
                            <td class="actions text-center" style="width: 100px">
                                <a href="<?php echo e(route('messagetemplates.showsendmessage', $template->id)); ?>" class="btn btn-xs btn-primary" title="Send message"><i class="fa fa-paper-plane"></i></a>
                                
                                <?php if($editAction == true): ?><a href="<?php echo e(route('messagetemplates.edit', $template->id)); ?>" class="btn btn-xs btn-info" title="Edit"><i class="fa fa-pencil"></i></a><?php endif; ?>
                                
                                
                                
                                
                                
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                    <tfoot>
                    <tr>
                        <th>No.</th>
                        <th>Message ID</th>
                        <th>Subject VN</th>
                        <th>Subject EN</th>
                        <th>Content VN</th>
                        <th>Content EN</th>
                        <th>Actions</th>
                    </tr>
                    </tfoot>
                </table>
            </div>

        </div>
        <!-- /.box-body -->
    </div>
    <!-- /.box -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>