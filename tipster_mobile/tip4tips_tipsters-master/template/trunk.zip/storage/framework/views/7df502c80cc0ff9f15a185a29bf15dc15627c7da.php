<input type="hidden" name="affected_object" value="<?php echo e(isset($affectedValue) ? $affectedValue : ''); ?>">
<input type="hidden" name="action_history" value="<?php echo e(isset($actionValue) ? $actionValue : ''); ?>">
<input type="hidden" name="description_history" value="<?php echo e(isset($descriptionValue) ? $descriptionValue : ''); ?>">
<input type="hidden" name="name_update" value="<?php echo e(isset($nameUpdateValue) ? $nameUpdateValue : ''); ?>">
<input type="hidden" name="name_object_history" value="<?php echo e(isset($nameObjectValue) ? $nameObjectValue : ''); ?>">
<input type="hidden" name="id_update" value="<?php echo e(isset($idUpdateValue) ? $idUpdateValue : ''); ?>">