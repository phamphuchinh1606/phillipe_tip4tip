<?php $__env->startSection('title', 'Compose New Message'); ?>
<?php $__env->startSection('styles'); ?>
    <!-- Bootstrap WYSIHTML5 -->
    <link href="<?php echo e(asset('css/admin/bootstrap3-wysihtml5.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/admin/select2.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <!-- Bootstrap WYSIHTML5 -->
    <script src="<?php echo e(asset('js/admin/bootstrap3-wysihtml5.all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/admin/select2.full.min.js')); ?>"></script>
    <script>
      $(function () {
        //Add text editor
        $("#compose-textarea").wysihtml5();
        $('.select2').select2();
      });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body.breadcrumbs'); ?>
    <?php echo e(Breadcrumbs::render('messages.create')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php echo $__env->make('messages.partials.column-left-mail', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- /.box-tools -->
        </div>
        <!-- /.box-header -->
                <form method="post" action="<?php echo e(route('messages.store')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="box-body">
                        <div class="form-group">
                            <select name="receiver" class="form-control select2" style="width: 100%;">
                                <option selected disabled>To:</option>
                                <?php $__currentLoopData = $receivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receiver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($receiver->id); ?>"><?php echo e($receiver->username); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </div>
                        <div class="form-group">
                            <input name="title" value="<?php echo e(old('title')); ?>" class="form-control" placeholder="Subject:">
                        </div>
                        <div class="form-group">
                        <textarea name="content" id="compose-textarea" class="form-control" style="height: 300px" required>

                        </textarea>
                        </div>
                        
                            
                                
                                
                            
                            
                        
                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer">
                        <div class="pull-right">
                            
                            <button type="submit" class="btn btn-primary"><i class="fa fa-envelope-o"></i> Send</button>
                        </div>
                        <button type="reset" class="btn btn-default"><i class="fa fa-times"></i> Discard</button>
                    </div>
                    <!-- /.box-footer -->
                </form>
            </div>
            <!-- /. box -->
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>