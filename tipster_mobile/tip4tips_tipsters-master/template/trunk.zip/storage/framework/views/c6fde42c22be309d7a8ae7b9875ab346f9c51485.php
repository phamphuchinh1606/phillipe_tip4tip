<?php use \App\Common\Utils; ?>

<?php $__env->startSection('title', 'Create Gift'); ?>
<?php $__env->startSection('javascript'); ?>
    <script src="<?php echo e(asset('js/admin/product.js')); ?>"></script>
    <script>
      $(document).ready(function () {
        var src = '<?php echo e(asset(Utils::$PATH__IMAGE)); ?>/';
        $("#imgAnchorInput").change(function() {
          $("#imgHandleInput").val($(this).val());
          src += $(this).val();
          console.log(src, $(this).val());
          $("#imgHandle").attr('src', src);
        }).change();
      })
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body.breadcrumbs'); ?>
    <?php echo e(Breadcrumbs::render('gifts.create')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if($createAction == false): ?>
        <div class="box box-danger">
            <div class="box-body text-center">
                <p>You do not access to this screen. Please contact to admin.</p>
            </div>
        </div>
    <?php else: ?>
        <div class="row">
            <!-- /.col -->
            <div class="col-md-8">
                <!-- create manager form -->

                <div class="box box-success">
                    <div class="box-header with-border">
                        <h3 class="box-title"><?php echo $__env->yieldContent('title'); ?></h3>
                        <span class="group__action pull-right">
                            <a href="<?php echo e(route('gifts.index')); ?>" class="btn btn-xs btn-default"><i class="fa fa-angle-left"></i> Back to list</a>
                        </span>
                    </div>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div><br />
                    <?php endif; ?>
                    <?php if(\Session::has('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e(\Session::get('success')); ?></p>
                        </div>
                    <?php endif; ?>
                    <!-- /.box-header -->
                    <form role="form" method="post" action="<?php echo e(route('gifts.store')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <input id="imgHandleInput" name="thumbnail" type="hidden" value="">
                    <div class="box-body">

                        <div class="form-group">
                            <label>Gifts name</label>
                            <input name="name" type="text" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Description</label>
                            <textarea name="description" class="form-control" rows="5"></textarea>
                        </div>

                        <div class="form-group">
                            <label>Point</label>
                            <input placeholder="0" name="point" type="number" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Category</label>
                            <select name="category" class="form-control">
                                <option value="" disabled selected>Please pick a category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                    </div>
                    <!-- /.box-body -->

                    <div class="box-footer">
                        <a href="<?php echo e(route('gifts.index')); ?>" class="btn btn-default">Cancel</a>
                        <button type="submit" class="btn btn-primary pull-right">Create</button>
                    </div>
                    </form>
                </div>

                <!-- /.box -->
            </div>
            <div class="col-md-4">
                <div class="box box-success">
                    <div class="box-header with-border">
                        <h3 class="box-title">Upload Gift Image</h3>
                    </div>
                    <div class="box-body">
                        <?php if($message = Session::get('success')): ?>
                            <div class="alert alert-success alert-block">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong><?php echo e($message); ?></strong>
                            </div>
                            <input id="imgAnchorInput" type="hidden" value="<?php echo e(Session::get('image')); ?>">

                        <?php endif; ?>
                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <strong>Whoops!</strong> There were some problems with your input.
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <div class="upload__area-thumbnail">
                            <p><span>
                            <img id="imgHandle" src="<?php echo e(asset('images/no_image_available.jpg')); ?>">
                        </span></p>
                        </div>
                        <div class="form__upload">
                            <?php echo Form::open(array('route' => 'image.upload.post','files'=>true)); ?>

                            <div class="form-inline-simple">
                                <?php echo Form::file('image', array('class' => 'form-control')); ?>

                                <button type="submit" class="btn btn-info">Upload</button>
                            </div>

                            <?php echo Form::close(); ?>


                        </div>
                    </div>
                </div>

                <div class="box box-success">
                    <div class="box-header with-border">
                        <h3 class="box-title">Category</h3>
                    </div>
                    <div class="box-body">
                        <div id="categoryForm" class="categoryForm" data-url="<?php echo e(route('gifts.addcategory')); ?>">
                            <div class="form-group">
                                <input name="categoryName" class="form-control" placeholder="Ex: Insurance">
                                <button id="catAdd" type="button" class="btn btn-primary"><i class="fa fa-plus"></i></button>
                            </div>
                            <div class="form-group">
                                <label id="catAlert" class="label"></label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>