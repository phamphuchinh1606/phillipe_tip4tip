<?php use App\Common\Common;?>

<?php $__env->startSection('title', 'List of Leads'); ?>

<?php $__env->startSection('javascript'); ?>
    <script src="<?php echo e(asset('js/admin/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/admin/dataTables.bootstrap.min.js')); ?>"></script>
    <script>
      $(function () {
        $('#viewList').DataTable({
          'paging'      : true,
          'lengthChange': false,
          'searching'   : true,
          'ordering'    : true,
          'info'        : true,
          'autoWidth'   : true,
          'order': [],
          'columnDefs': [ { orderable: false, targets: [0]}]
        })
      })
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body.breadcrumbs'); ?>
    <?php echo e(Breadcrumbs::render('leads')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="box box-list">
        <div class="box-header">
            <h3 class="box-title"><?php echo $__env->yieldContent('title'); ?></h3>
            <?php if($createAction == true): ?><a href="<?php echo e(route('leads.create')); ?>" class="btn btn-md btn-primary pull-right"><i class="fa fa-plus"></i> New Lead</a><?php endif; ?>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
            <?php if(\Session::has('success')): ?>
                <div class="alert alert-success clearfix">
                    <p><?php echo e(\Session::get('success')); ?></p>
                </div><br />
            <?php endif; ?>
            <div class="table-responsive">
                <table id="viewList" class="table table-hover table-striped">
                    <thead>
                    <tr>
                        <th>No.</th>
                        <th>Lead</th>
                        <th>Product</th>
                        <th>Tipster</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $i= 0; ?>
                    <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i++ ?>
                        <tr>
                            <td width="40" align="center"><?php echo e($i); ?></td>
                            <td><?php echo e($lead->fullname); ?></td>
                            <td><?php echo e($lead->product); ?></td>
                            <td><?php echo e($lead->tipster); ?></td>
                            <td><?php echo e(Common::dateFormat($lead->created_at, 'd F Y')); ?></td>
                            <td><span class="label-status <?php echo e(Common::showColorStatus($lead->status)); ?>"><?php echo e(Common::showNameStatus($lead->status)); ?></span></td>
                            <td class="actions text-center" style="width: 100px">
                                <a href="<?php echo e(route('leads.show', $lead->id)); ?>" class="btn btn-xs btn-success" title="View"><i class="fa fa-eye"></i></a>
                                <?php if($editAction == true): ?><a href="<?php echo e(route('leads.edit', $lead->id)); ?>" class="btn btn-xs btn-info" title="Edit"><i class="fa fa-pencil"></i></a><?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                    <tfoot>
                    <tr>
                        <th>No.</th>
                        <th>Lead</th>
                        <th>Product</th>
                        <th>Tipster</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                    </tfoot>
                </table>
            </div>
        </div>
        <!-- /.box-body -->
    </div>
    <!-- /.box -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>