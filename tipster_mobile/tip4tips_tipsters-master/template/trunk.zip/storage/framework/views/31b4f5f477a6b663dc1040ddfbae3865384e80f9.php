<?php
use App\Common\Common;
use App\Common\Utils;
?>

<?php $__env->startSection('title', 'Edit User'); ?>
<?php $__env->startSection('javascript'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body.breadcrumbs'); ?>
    <?php echo e(Breadcrumbs::render('users.edit')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if($editAction == false): ?>
        <div class="box box-danger">
            <div class="box-body text-center">
                <p>You do not access to this screen. Please contact to admin.</p>
            </div>
        </div>
    <?php else: ?>
        <div class="row">
            <div class="col-md-4 col-md-push-8">

                <!-- Profile Image -->
                <div class="box box-warning">
                    <div class="box-body box-profile">
                        <div class="upload__area-image">
                        <span>
                            <img id="imgHandle" src="<?php echo e(asset(Utils::$PATH__IMAGE)); ?>/<?php echo e($user->avatar); ?>">
                            <label for="imgAnchorInput">Upload image</label>
                        </span>
                            <p><small>(Please upload a file of type: jpeg, png, jpg, gif, svg.)</small></p>
                        </div>
                        <div class="form__upload">
                            <?php echo Form::open(array('route' => 'image.upload.post','files'=>true)); ?>

                            <div class="form-inline-simple">
                                <?php echo Form::file('image', array('class' => 'form-control', 'id' => 'imgAnchorInput', 'onchange' =>'loadFile(event)')); ?>

                                
                            </div>
                            <script>
                              var loadFile = function(event) {
                                var output = document.getElementById('imgHandle');
                                output.src = URL.createObjectURL(event.target.files[0]);
                                document.getElementById('imgHandleInput').files = event.target.files;
                              };
                            </script>

                            <?php echo Form::close(); ?>


                        </div>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->


            </div>
            <!-- /.col -->
            <div class="col-md-8 col-md-pull-4">
                <!-- create manager form -->
                <div class="box box-warning">
                    <div class="box-header with-border">
                        <h3 class="box-title"><?php echo $__env->yieldContent('title'); ?></h3>
                        <span class="group__action pull-right">
                            <a href="<?php echo e(route('users.index')); ?>" class="btn btn-xs btn-default"><i class="fa fa-angle-left"></i> Back to list</a>
                        </span>

                    </div>
                    <?php if($errors->any()): ?>
                        <div class="box-body">
                            <div class="alert alert-danger">
                                <?php if(count($errors) > 0): ?>
                                    <strong>Whoops!</strong> There were some problems with your input.
                                <?php endif; ?>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div><?php endif; ?>
                    <!-- /.box-header -->
                    <form role="form" method="post" action="<?php echo e(route('users.update', $id)); ?>" enctype = "multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <input name="_method" type="hidden" value="PATCH">
                        <input id="imgHandleInput" name="avatar" type="file" value="<?php echo e($user->avatar); ?>">
                    <div class="box-body">
                        <div class="row">
                            <div class="col-sm-6">
                                <!-- text input -->
                                <div class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
                                    <label>Username</label>
                                    <input name="username" type="text" class="form-control" value="<?php echo e($user->username); ?>">
                                    <?php if($errors->has('username')): ?>
                                        <span class="help-block">
                                                <strong><?php echo e($errors->first('username')); ?></strong>
                                            </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group<?php echo e($errors->has('fullname') ? ' has-error' : ''); ?>">
                                    <label>Full name</label>
                                    <input name="fullname" type="text" class="form-control" value="<?php echo e($user->fullname); ?>" placeholder="Enter ...">
                                    <?php if($errors->has('fullname')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('fullname')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Birthday</label>
                                    <input name="birthday" type="date" class="form-control" value="<?php echo e($user->birthday); ?>" placeholder="Enter ...">
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label style="width: 100%">Gender</label>
                                    <div class="radio-inline">
                                        <label><input type="radio" value="0" name="gender" <?php if($user->gender == 0): ?> checked <?php endif; ?>>
                                            Male
                                        </label>
                                    </div>
                                    <div class="radio-inline">
                                        <label><input type="radio" value="1" name="gender" <?php if($user->gender == 1): ?> checked <?php endif; ?>>
                                            Female
                                        </label>
                                    </div>

                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                    <label>Email</label>
                                    <input name="email" type="text" class="form-control" value="<?php echo e($user->email); ?>" placeholder="Enter ...">
                                    <?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                                <strong><?php echo e($errors->first('email')); ?></strong>
                                            </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Phone</label>
                                    <input name="phone" type="text" class="form-control" value="<?php echo e($user->phone); ?>" placeholder="Enter ...">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Address</label>
                                    <input name="address" type="text" class="form-control" value="<?php echo e($user->address); ?>" placeholder="Enter ...">
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Region</label>
                                    <select name="region" class="form-control">
                                        <option value="" disabled selected>Please pick a region</option>
                                        <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($region->id); ?>" <?php if($region->id == $user->region_id): ?> selected <?php endif; ?>><?php echo e($region->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Department</label>
                                    <select class="form-control" name="department">
                                        <option value="" disabled selected>Please pick a department</option>
                                        <?php $__currentLoopData = $roletypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roletype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <optgroup label="<?php echo e($roletype->name); ?>">
                                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($role->roletype_id == $roletype->id): ?>
                                                        <option value="<?php echo e($role->id); ?>" <?php if($user->role_id == $role->id): ?> selected <?php endif; ?>><?php echo e($role->name); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </optgroup>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label style="width: 100%">Status</label>
                                    <div class="radio-inline">
                                        <label>
                                            <input type="radio" value="0" name="status" <?php if($user->delete_is == 0): ?> checked <?php endif; ?>>
                                            Active
                                        </label>
                                    </div>
                                    <div class="radio-inline">
                                        <label>
                                            <input type="radio" value="1" name="status" <?php if($user->delete_is == 1): ?> checked <?php endif; ?>>
                                            Non Active
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.box-body -->

                    <div class="box-footer">
                        <a href="<?php echo e(route('users.index')); ?>" class="btn btn-default">Cancel</a>
                        <button type="submit" class="btn btn-primary pull-right">Update</button>
                    </div>
                    </form>
                </div>
                <!-- /.box -->
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>