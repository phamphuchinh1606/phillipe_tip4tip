<?php $__env->startSection('title', 'Edit Assignment'); ?>

<?php $__env->startSection('content'); ?>
    <?php if($editAction == false): ?>
        <div class="box box-danger">
            <div class="box-body text-center">
                <p>You do not access to this screen. Please contact to admin.</p>
            </div>
        </div>
    <?php else: ?>
    <div class="row">
        <!-- /.col -->
        <div class="col-md-8 col-md-offset-2">
            <!-- create manager form -->

            <div class="box box-warning">
                <div class="box-header with-border">
                    <h3 class="box-title">Edit an Assignment</h3>
                </div>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <!-- /.box-header -->
                <form role="form" method="post" action="<?php echo e(route('assignments.update', $id)); ?>">
                    <?php echo e(csrf_field()); ?>

                    <input name="_method" type="hidden" value="PATCH">
                    <div class="box-body">
                        <div class="form-group">
                            <label>Please pick a Lead to assign:</label>
                            <select name="lead" class="form-control">
                                <option readonly="true">Please pick a lead</option>
                                <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($lead->id); ?>" <?php if($lead->id == $assignment->lead_id): ?> selected <?php endif; ?>><?php echo e($lead->fullname); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Assign to Consultant</label>
                            <select name="consultant" class="form-control">
                                <option readonly="true">Please pick a consultant</option>
                                <?php $__currentLoopData = $consultants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($consultant->id); ?>" <?php if($consultant->id == $assignment->consultant_id): ?> selected <?php endif; ?>><?php echo e($consultant->fullname); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>


                    </div>
                <!-- /.box-body -->

                <div class="box-footer">
                    <a href="<?php echo e(route('assignments.index')); ?>" class="btn btn-default">Cancel</a>
                    <button type="submit" class="btn btn-primary pull-right">Update</button>
                </div>
            </form>
            </div>

            <!-- /.box -->
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>