<?php use \App\Model\Role;?>

<?php $__env->startSection('title', 'List of Tipsters'); ?>
<?php $__env->startSection('javascript'); ?>
    <script src="<?php echo e(asset('js/admin/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/admin/dataTables.bootstrap.min.js')); ?>"></script>
    <script>
      $(function () {
        $('#viewList').DataTable({
          'paging'      : true,
          'lengthChange': false,
          'searching'   : true,
          'ordering'    : true,
          'info'        : true,
          'autoWidth'   : true,
          'order': [],
          'columnDefs': [ { orderable: false, targets: [0]}]
        })
      })
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body.breadcrumbs'); ?>
    <?php echo e(Breadcrumbs::render('tipsters')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="box box-list">
        <div class="box-header">
            <h3 class="box-title"><?php echo $__env->yieldContent('title'); ?></h3>
            <?php if($createAction == true): ?><a href="<?php echo e(route('tipsters.create')); ?>" class="btn btn-md btn-primary pull-right"><i class="fa fa-plus"></i> New Tipster</a><?php endif; ?>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
            <?php if(\Session::has('success')): ?>
                <div class="alert alert-success clearfix">
                    <p><?php echo e(\Session::get('success')); ?></p>
                </div><br />
            <?php endif; ?>
            <div class="table-responsive">
                <table id="viewList" class="table table-bordered table-striped tbsty">
                    <thead>
                    <tr>
                        <th width="30">No.</th>
                        <th>Tipster</th>
                        <th width="50">Points</th>
                        <th>Email</th>
                        <th>Level</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $i= 0; ?>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i++ ?>
                        <tr>
                            <td><?php echo $i?></td>
                            <td><?php echo e($user->username); ?><span class="label-small"><?php echo e($user->fullname); ?></span></td>
                            <td><?php echo e($user->point); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td>  <?php echo e(Role::getNameRoleByID($user->role_id)); ?></td>
                            <td><?php if($user->delete_is == 0): ?><label class="label label-success">Active</label><?php else: ?> <label class="label label-danger">Non active</label> <?php endif; ?></td>
                            <td class="actions text-center" style="width: 100px">
                                <a href="<?php echo e(route('tipsters.show', $user->id)); ?>" class="btn btn-xs btn-success" title="View"><i class="fa fa-eye"></i></a>
                                <?php if($editAction == true): ?><a href="<?php echo e(route('tipsters.edit', $user->id)); ?>" class="btn btn-xs btn-info" title="Edit"><i class="fa fa-pencil"></i></a><?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                    <tfoot>
                    <tr>
                        <th>No.</th>
                        <th>Tipster</th>
                        <th>Points</th>
                        <th>Email</th>
                        <th>Level</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                    </tfoot>
                </table>
            </div>
        </div>
        <!-- /.box-body -->
    </div>
    <!-- /.box -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>