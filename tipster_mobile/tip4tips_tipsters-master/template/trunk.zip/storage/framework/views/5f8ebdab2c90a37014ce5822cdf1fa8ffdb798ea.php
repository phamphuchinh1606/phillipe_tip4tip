<?php
use App\Common\Common;
use App\Model\LeadProcess;
use App\Model\Region;
use App\Model\Product;
use App\User;
use App\Model\Assignment;
use App\Model\Role;
?>

<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">

        <div class="col-md-8">
            <!-- About Me Box -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">
                        Profile</h3>
                    <span class="group__action pull-right">
                        <a href="<?php echo e(route('leads.index')); ?>" class="btn btn-xs btn-default"><i class="fa fa-angle-left"></i> Back to list</a>
                                <a href="<?php echo e(route('leads.edit', $lead->id)); ?>" class="btn btn-xs btn-info"><i class="fa fa-pencil"></i> Edit</a>
                        <?php if($deleteAction == true): ?><form class="inline" action="<?php echo e(action('LeadsController@destroy', $lead->id)); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                            <input name="_method" type="hidden" value="DELETE">
                                <button title="Delete this user" class="btn btn-xs btn-danger" type="submit"><i class="fa fa-trash"></i> Delete</button>
                            </form><?php endif; ?>
                            </span>

                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="block__profile">
                        <h3 class="profile__name"><?php if($lead->gender == 0): ?> Mr. <?php else: ?> Mrs/Miss. <?php endif; ?> <?php echo e($lead->fullname); ?></h3>

                        <?php if($lead->phone): ?><p class="text-muted">
                            <span class="text-label"><i class="fa fa-phone margin-r-5"></i> Phone</span>
                            <span class="text-highlight"><?php echo e($lead->phone); ?></span>
                        </p><?php endif; ?>

                        <?php if($lead->email): ?><p class="text-muted">
                        <span class="text-label"><i class="fa fa-envelope margin-r-5"></i> Email</span>
                        <span class="text-highlight"><?php echo e($lead->email); ?></span>
                        </p><?php endif; ?>
                        <p class="text-muted">
                        <span class="text-label"><i class="fa fa-map-marker margin-r-5"></i> Region</span>
                        <span class="text-highlight"><?php if(!empty(Region::getNameByID($lead->region_id))): ?>
                        <?php echo e(Region::getNameByID($lead->region_id)->name); ?>

                        <?php endif; ?></span>
                        </p>
                        <p class="text-muted">
                        <span class="text-label"><i class="fa fa-shield margin-r-5"></i> Product</span>
                        <span class="text-highlight"> <?php if(!empty(Product::getProductByID($lead->product_id))): ?><?php echo e(Product::getProductByID($lead->product_id)->name); ?><?php endif; ?> </span>
                        </p>
                        <?php if($lead->notes): ?><p class="text-muted">
                        <span class="text-label"><i class="fa fa-file-text-o margin-r-5"></i> Notes</span>
                        <span class="text-highlight"><?php echo e($lead->notes); ?></span>
                        </p><?php endif; ?>
                    </div>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-4">

            <!-- Profile Image -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Advanced information</h3>
                </div>
                <div class="box-body">
                    <div class="block__action">
                        <p>Tipster reference:
                            <span class="text-highlight"><?php echo e(User::getUserByID($lead->tipster_id)->fullname); ?></span></p>
                    </div>
                    <div class="block__action">
                        <p>Be Assigned to:<br/>
                            <?php if(!empty(Assignment::getConsultantByLead($lead->id)->consultant_id)): ?>
                                <span class="text-highlight">
                                    <?php echo e(User::getUserByID(Assignment::getConsultantByLead($lead->id)->consultant_id)->fullname); ?>-
                                    <?php echo e(Role::getNameRoleByID(User::getUserByID(Assignment::getConsultantByLead($lead->id)->consultant_id)->role_id)); ?></span>
                            <?php else: ?>
                                Not assign yet.
                            <?php endif; ?>
                        </p>
                    </div>
                    <div class="block__action">
                        <p>Status history</p>
                        <?php if(LeadProcess::getStatusByLead($lead->id)): ?>
                            <ul class="list-unstyled history-statuses">
                                <?php $__currentLoopData = LeadProcess::getStatusByLead($lead->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="<?php echo e(Common::showColorStatus($status->status_id)); ?>">
                                        <span class="history__time"><?php echo e(Common::dateFormat($status->created_at,'d-M-Y H:i')); ?></span>
                                        <span class="history__info"><?php echo e(Common::showNameStatus($status->status_id)); ?></span>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li class="label-new">
                                    <span class="history__time"><?php echo e(Common::dateFormat($lead->created_at, 'd-M-Y H:i')); ?></span>
                                    <span class="history__info">New</span>
                                </li>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>