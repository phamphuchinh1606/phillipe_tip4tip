<?php if($paginator->hasPages()): ?>
    <ul class="pagination">
        
        current-page : <?php echo e($paginator->currentPage()); ?>

        total-page : <?php echo e($paginator->total()); ?>

        Tong record : <?php echo e($paginator->count()); ?>

        <?php if($paginator->onFirstPage()): ?>
            <li class="disabled"><span><?php echo app('translator')->getFromJson('pagination.previous'); ?></span></li>
        <?php else: ?>
            <li><a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev"><?php echo app('translator')->getFromJson('pagination.previous'); ?></a></li>
        <?php endif; ?>

        
        <?php if($paginator->hasMorePages()): ?>
            <li><a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next"><?php echo app('translator')->getFromJson('pagination.next'); ?></a></li>
        <?php else: ?>
            <li class="disabled"><span><?php echo app('translator')->getFromJson('pagination.next'); ?></span></li>
        <?php endif; ?>
    </ul>
<?php endif; ?>
