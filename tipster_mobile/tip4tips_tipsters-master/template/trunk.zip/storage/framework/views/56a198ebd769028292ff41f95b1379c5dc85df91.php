<?php use App\Common\Common;?>

<?php $__env->startSection('title', 'Read Email'); ?>
<?php $__env->startSection('body.breadcrumbs'); ?>
    <?php echo e(Breadcrumbs::render('messages.show')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
                <?php echo $__env->make('messages.partials.column-left-mail', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <!-- /.box-header -->
                <div class="box-body no-padding">
                    <div class="mailbox-read-message">
                    <!-- /.mail-box-messages --></div>
                    <div class="mailbox-read-info">
                        <h3><?php echo e($message->title); ?></h3>
                        <h5>From: <?php echo e($message->authorMess); ?>

                            <span class="mailbox-read-time pull-right"><?php echo Common::dateFormatText($message->created_at); ?></span></h5>
                    </div>
                    <!-- /.mailbox-read-info -->

                    <div class="mailbox-read-message">
                        <?php echo html_entity_decode($message->content); ?>

                    </div>
                    <!-- /.mailbox-read-message -->
                </div>

                <div class="box-footer">
                    <div class="pull-right">
                        <button type="button" class="btn btn-default"><i class="fa fa-reply"></i> Reply</button>
                        
                    </div>
                    <form class="inline" action="<?php echo e(route('messages.deletetrash', $message->id)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input name="_method" type="hidden" value="DELETE">
                        <button type="submit" class="btn btn-default"><i class="fa fa-trash-o"></i> Delete</button>
                    </form>
                    
                </div>
                <!-- /.box-footer -->
            </div>
            <!-- /. box -->
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>