<?php
use App\Common\Common;
use App\Common\Utils;
?>

<?php $__env->startSection('title', 'User detail'); ?>
<?php $__env->startSection('body.breadcrumbs'); ?>
    <?php echo e(Breadcrumbs::render('users.show')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-4 col-md-push-8">

            <!-- Profile Image -->
            <div class="box box-primary">
                <div class="box-body box-profile">
                    <div class="upload__area-image">
                        <span><img id="imgHandle" src="<?php if($user->avavatar): ?><?php echo e(asset(Utils::$PATH__IMAGE)); ?>/<?php echo e($user->avatar); ?><?php else: ?><?php echo e(asset(Utils::$PATH__DEFAULT__AVATAR)); ?>" <?php endif; ?> ></span>
                    </div>
                    <p class="text-muted text-center" title="Username">
                        <strong><i class="fa fa-user margin-r-5"></i> <?php echo e($user->username); ?></strong>
                    </p>
                    <hr>

                    <p class="text-center">
                        <?php if($user->delete_is == 0): ?>
                            <span class="label label-success">Active</span>
                        <?php else: ?>
                            <span class="label label-danger">Non active</span>
                        <?php endif; ?>
                    </p>

                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->


        </div>
        <!-- /.col -->
        <div class="col-md-8 col-md-pull-4">
            <!-- About Me Box -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title"><?php echo $__env->yieldContent('title'); ?></h3>
                    <span class="group__action pull-right">
                        <a href="<?php echo e(route('users.index')); ?>" class="btn btn-xs btn-default"><i class="fa fa-angle-left"></i> Back to list</a>
                        <?php if($editAction == true): ?>
                        <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-xs btn-info"><i class="fa fa-pencil"></i> Edit</a>
                        <?php endif; ?>
                        <?php if($deleteAction == true && $user->delete_is==0): ?>
                            <a data-toggle="modal" data-target="#popup-confirm" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i> Delete</a>
                        <?php endif; ?>
                    </span>

                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="row box-line">
                        <div class="col-sm-6">
                            <p class="text-muted">
                                <i class="fa fa-address-book margin-r-5"></i> Fullname
                                <span class="text-highlight"><?php echo e($user->fullname); ?></span>
                            </p>
                        </div>
                        <div class="col-sm-6">
                            <p class="text-muted">
                                <i class="fa fa-building margin-r-5"></i> Department
                                <span class="text-highlight"><?php echo e($user->role); ?> - <?php echo e($user->roletype); ?></span>

                            </p>
                        </div>
                    </div>
                    <div class="row box-line">
                        <div class="col-sm-6">
                            <p class="text-muted">
                                <i class="fa fa-calendar margin-r-5"></i> Birthday
                                <span class="text-highlight"><?php echo e($user->birthday); ?></span>
                            </p>
                        </div>
                        <div class="col-sm-6">
                            <p class="text-muted">
                                <i class="fa fa-venus-mars margin-r-5"></i> Gender
                                <span class="text-highlight"><?php echo e($user->genderName); ?></span>
                            </p>
                        </div>
                    </div>

                    <div class="row box-line">
                        <div class="col-sm-6">
                            <p class="text-muted">
                                <i class="fa fa-envelope margin-r-5"></i> Email
                                <span class="text-highlight"><?php echo e($user->email); ?></span>
                            </p>
                        </div>
                        <div class="col-sm-6">
                            <p class="text-muted">
                                <i class="fa fa-phone margin-r-5"></i> Phone
                                <span class="text-highlight"><?php echo e($user->phone); ?></span>
                            </p>
                        </div>
                    </div>

                    <div class="row box-line">
                        <div class="col-sm-6">
                            <p class="text-muted">
                                <i class="fa fa-home margin-r-5"></i> Address
                                <span class="text-highlight"><?php echo e($user->address); ?></span>
                            </p>
                        </div>
                        <div class="col-sm-6">
                            <p class="text-muted">
                                <i class="fa fa-map-marker margin-r-5"></i> Location
                                <span class="text-highlight"><?php echo e($user->region); ?></span></p>
                        </div>
                    </div>
                    <div class="row box-line">
                        <div class="col-sm-12">
                            <p>
                                <i class="fa fa-file-text-o margin-r-5"></i> Notes
                                <span class="text-highlight"></span>
                            </p>
                        </div>
                    </div>

                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->
    <?php if($deleteAction == true): ?>
    
    <div id="popup-confirm" class="modal popup-confirm" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <p>Do you really want to delete user "<?php echo e($user->fullname); ?>" ?</p>
                    <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Cancel</button>
                    <form class="inline" action="<?php echo e(route('users.destroy', $user->id)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input name="_method" type="hidden" value="DELETE">
                        <button class="btn btn-sm btn-danger" type="submit">Yes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>