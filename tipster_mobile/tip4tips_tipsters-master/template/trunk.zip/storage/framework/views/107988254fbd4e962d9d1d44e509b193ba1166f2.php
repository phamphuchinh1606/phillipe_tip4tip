<?php use App\Common\Common; ?>

<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('body.breadcrumbs'); ?>
    <?php echo e(Breadcrumbs::render('dashboard')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('css/jquery.scrollbar.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.bundle.min.js"></script>
    <script src="<?php echo e(asset('js/jquery.scrollbar.js')); ?>"></script>
<script>
  var ctx = document.getElementById("pieChartLeads").getContext('2d');
  var pieChartLeads = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ["New", "Call", "Quote", "Win", "Lost"],
      datasets: [{
        label: '# of Votes',
        data: [<?php echo e($new); ?>, <?php echo e($call); ?>, <?php echo e($quote); ?>, <?php echo e($win); ?>, <?php echo e($lost); ?>],
        backgroundColor: [
          '<?php echo e(Common::colorStatus(0)); ?>',
          '<?php echo e(Common::colorStatus(1)); ?>',
          '<?php echo e(Common::colorStatus(2)); ?>',
          '<?php echo e(Common::colorStatus(3)); ?>',
          '<?php echo e(Common::colorStatus(4)); ?>'
        ],
        borderColor: [
          '<?php echo e(Common::colorStatus(0)); ?>',
          '<?php echo e(Common::colorStatus(1)); ?>',
          '<?php echo e(Common::colorStatus(2)); ?>',
          '<?php echo e(Common::colorStatus(3)); ?>',
          '<?php echo e(Common::colorStatus(4)); ?>'
        ],
        borderWidth: 1
      }]
    },
    options: {
      cutoutPercentage: 80,
      responsive: true,
      legend: false,
      legendCallback: function(chart) {
        var legendHtml = [];
        legendHtml.push('<ul class="chart-legend clearfix">');
        var item = chart.data.datasets[0];
        for (var i=0; i < item.data.length; i++) {
          legendHtml.push('<li>');
          legendHtml.push('<span class="chart-legend-icon" style="color:'+ item.backgroundColor[i] +'"><i class="fa fa-circle-o"></i></span>');
          legendHtml.push('<span class="chart-legend-label-text"> '+chart.data.labels[i]+'</span>');
          legendHtml.push('</li>');
        }

        legendHtml.push('</ul>');
        return legendHtml.join("");
      },
      title: {
        display: true,
        text: ''
      },
      animation: {
        animateScale: true,
        animateRotate: true
      }
    }
  });
  $('#pieChart-legend-con').html(pieChartLeads.generateLegend());

  jQuery(document).ready(function(){
    jQuery('.scrollbar-macosx').scrollbar({
      "showArrows": true,
      "scrollx": "advanced",
      "scrolly": "advanced"
    });
  });
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Main row -->
    <div class="row dashboard">
        <div class="col-sm-12 col-lg-6">
            <!-- LEADS LIST -->
            <div class="box box-default">
                <div class="box-header with-border">
                    <h3 class="box-title">Recent Leads(5 Leads)</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="row">
                        <ul class="ul__users lead__list clearfix">
                            <?php $__currentLoopData = $recentleads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recentlead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <span class="lead__box">
                                    <span class="lead__create-at"><?php echo e($recentlead->created_date); ?></span>
                                    <a class="lead__info" href="<?php echo e(route('leads.show', $recentlead->id)); ?>">
                                        <span class="lead__name"><?php echo e($recentlead->fullname); ?>

                                            <span class="lead__status" style="color:<?php echo e($recentlead->status_color); ?>" ><?php echo e($recentlead->status_text); ?></span>
                                        </span>
                                        <span class="lead__product"><?php echo e($recentlead->product); ?></span>
                                    </a>
                                </span>

                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <!-- /.row -->
                </div>
                <div class="box-footer text-center">
                    <a href="<?php echo e(route('leads.index')); ?>" class="uppercase">View More Leads &#8594;</a>
                </div>
            </div>
            <!-- /.box -->
            <!--/.box -->
        </div>
        <div class="col-sm-12 col-lg-6">
            <!-- LEADS LIST -->
            <div class="box box-default">
                <div class="box-header with-border">
                    <h3 class="box-title">Latest status (5 last Leads)</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="chart-responsive">
                                <canvas id="pieChartLeads" height="200"></canvas>
                            </div>
                            <!-- ./chart-responsive -->
                        </div>
                        <!-- /.col -->
                        <div class="col-xs-12">
                            <div id="pieChart-legend-con"></div>
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </div>
                <div class="box-footer text-center">
                    <a href="<?php echo e(route('leads.index')); ?>" class="uppercase">View More Leads &#8594;</a>
                </div>
            </div>
            <!-- /.box -->
            <!--/.box -->
        </div>
    </div>
    <div class="row dashboard">
        <div class="col-sm-12 col-lg-6">
            <!-- Tipster LIST -->
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h3 class="box-title">Most active Tipsters( 5 Tipsters)</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body no-padding">
                    <ul class="users-list ul__users clearfix">
                        <?php $__currentLoopData = $mostactivetipsters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mostactivetipster): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e(route('tipsters.show', $mostactivetipster->id)); ?>">
                                    <span class="users-list-avatar">
                                        <img src="<?php echo e(asset('images/upload')); ?>/<?php echo e($mostactivetipster->avatar); ?>" alt="<?php echo e($mostactivetipster->username); ?>">
                                    </span>
                                    <span class="users-list-info">
                                        <span class="users-list-name">
                                            <?php echo e($mostactivetipster->username); ?>

                                        </span>
                                        <span class="users-list-fullname"><?php echo e($mostactivetipster->fullname); ?></span>

                                    </span>
                                    <span class="users-list-status">
                                        <span class="users-list-status-ttl">Leads: <?php echo e($mostactivetipster->countStatus); ?></span>
                                        <span class="users-list-status-detail"><?php echo $mostactivetipster->strStatusLead; ?></span>
                                    </span>
                                    <span class="users-list-points"><?php echo e($mostactivetipster->point); ?> <small>points</small></span>
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <!-- /.users-list -->
                </div>
                <!-- /.box-body -->
                <div class="box-footer text-center">
                    <a href="<?php echo e(route('tipsters.index')); ?>" class="uppercase">View More Tipsters &#8594;</a>
                </div>
                <!-- /.box-footer -->
            </div>
            <!--/.box -->
        </div>
        <div class="col-sm-12 col-lg-6">
            <!-- CONSULTANT LIST -->
            <div class="box box-danger">
                <div class="box-header with-border">
                    <h3 class="box-title">Latest Activities (5 Activities)</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body no-padding">
                    <ul class="activities">
                        <?php $__currentLoopData = $logActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logActivity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="activity">

                                <span class="activity__detail">
                                    <span class="activity__time"><?php echo Common::dateFormatText($logActivity->created_at); ?></span>
                                    <span class="activity__info">
                                        <span class="activity__user-name">
                                            <a href="<?php echo e(route('users.show', $logActivity->user_id)); ?>" title="<?php echo e($logActivity->fullname); ?>"><?php echo e($logActivity->user_name); ?></a>
                                        </span>
                                        <span class="activity__description"><?php echo e($logActivity->description); ?></span>
                                    </span>


                                </span>

                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                </div>
                <!-- /.box-body -->
                <div class="box-footer text-center">
                    <a href="<?php echo e(route('activities.index')); ?>" class="uppercase">View More Activities &#8594;</a>
                </div>
                <!-- /.box-footer -->
            </div>
            <!--/.box -->
        </div>
    </div>
    <!-- /.row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>