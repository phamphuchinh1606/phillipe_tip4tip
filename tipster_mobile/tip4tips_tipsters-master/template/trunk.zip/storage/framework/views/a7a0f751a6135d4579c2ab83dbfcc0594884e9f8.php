<?php
use App\Common\Common;
use App\Common\Utils;
?>

<?php $__env->startSection('title', 'Tipster detail'); ?>
<?php $__env->startSection('javascript'); ?>
    <script src="<?php echo e(asset('js/admin/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/admin/dataTables.bootstrap.min.js')); ?>"></script>
    <script>
      $(function () {
        $('#viewList').DataTable({
          'paging'      : true,
          'lengthChange': false,
          'searching'   : true,
          'ordering'    : true,
          'info'        : true,
          'autoWidth'   : true
        })
      })
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body.breadcrumbs'); ?>
    <?php echo e(Breadcrumbs::render('tipsters.show')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-4 col-md-push-8">

            <!-- Profile Image -->
            <div class="box box-primary">
                <div class="box-body box-profile">
                    <div class="upload__area-image">
                        <span><img id="imgHandle" src="<?php if($user->avavatar): ?><?php echo e(asset(Utils::$PATH__IMAGE)); ?>/<?php echo e($user->avatar); ?><?php else: ?><?php echo e(asset(Utils::$PATH__DEFAULT__AVATAR)); ?>" <?php endif; ?> ></span>
                    </div>
                    <p class="text-muted text-center" title="Username">
                        <strong><i class="fa fa-user margin-r-5"></i> <?php echo e($user->username); ?></strong>
                    </p>
                    <p class="text-muted text-center tipster__point-total" title="Point total">
                        <span><?php echo e($user->point); ?></span><br/>
                        points
                    </p>

                    <hr>

                    <p class="text-center">
                        <?php if($user->delete_is == 0): ?>
                            <span class="label label-success">Active</span>
                        <?php else: ?>
                            <span class="label label-danger">Non active</span>
                        <?php endif; ?>
                    </p>

                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->


        </div>
        <!-- /.col -->
        <div class="col-md-8 col-md-pull-4">
            <!-- About Me Box -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title"><?php echo $__env->yieldContent('title'); ?></h3>
                    <span class="group__action pull-right">
                        <a href="<?php echo e(route('tipsters.index')); ?>" class="btn btn-xs btn-default"><i class="fa fa-angle-left"></i> Back to list</a>
                        <?php if($editAction == true): ?>
                            <a href="<?php echo e(route('tipsters.edit', $user->id)); ?>" class="btn btn-xs btn-info"><i class="fa fa-pencil"></i> Edit</a>
                        <?php endif; ?>
                        <?php if($deleteAction == true): ?>
                            <a data-toggle="modal" data-target="#popup-confirm" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i> Delete</a>
                        <?php endif; ?>


                    </span>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="row box-line">
                        <div class="col-sm-6">
                            <p class="text-muted">
                                <i class="fa fa-globe margin-r-5"></i> Preferred language
                                <span class="text-highlight"><?php echo e(Common::showTextLanguage($user->preferred_lang)); ?></span>
                            </p>
                        </div>
                    </div>
                    <div class="row box-line">
                        <div class="col-sm-6">
                            <p class="text-muted">
                                <i class="fa fa-address-book margin-r-5"></i> Fullname
                                <span class="text-highlight"><?php echo e($user->fullname); ?></span>
                            </p>
                        </div>
                        <div class="col-sm-6">
                            <p class="text-muted">
                                <i class="fa fa-building margin-r-5"></i> Level
                                <span class="text-highlight"><?php echo e($role->name); ?> - <?php echo e($roletype->name); ?></span>
                            </p>
                        </div>
                    </div>
                    <div class="row box-line">
                        <div class="col-sm-6">

                            <p class="text-muted">
                                <i class="fa fa-calendar margin-r-5"></i> Birthday
                                <span class="text-highlight"><?php echo e($user->birthday); ?></span>
                            </p>
                        </div>
                        <div class="col-sm-6">
                            <p class="text-muted">
                                <i class="fa fa-venus-mars margin-r-5"></i> Gender
                                <span class="text-highlight"><?php echo e($user::showGender($user->gender)); ?></span>
                            </p>
                        </div>
                    </div>

                    <div class="row box-line">
                        <div class="col-sm-6">
                            <p class="text-muted">
                                <i class="fa fa-envelope margin-r-5"></i> Email
                                <span class="text-highlight"><?php echo e($user->email); ?></span>
                            </p>
                        </div>
                        <div class="col-sm-6">
                            <p class="text-muted">
                                <i class="fa fa-phone margin-r-5"></i> Phone
                                <span class="text-highlight"><?php echo e($user->phone); ?></span>
                            </p>
                        </div>
                    </div>

                    <div class="row box-line">
                        <div class="col-sm-6">
                            <p class="text-muted">
                                <i class="fa fa-home margin-r-5"></i> Address
                                <span class="text-highlight"><?php echo e($user->address); ?></span>
                            </p>
                        </div>
                        <div class="col-sm-6">
                            <p class="text-muted">
                                <i class="fa fa-map-marker margin-r-5"></i> Location
                                <span class="text-highlight"><?php echo e(\App\Model\Region::getNameByID($user->region_id)->name); ?></span>
                            </p>
                        </div>
                    </div>
                    
                        
                            
                                
                                
                            
                        
                    

                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->

            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Points History</h3>
                </div>
                <div class="box-body">
                    <table id="viewList" class="table table-striped lead__ref">
                        <thead>
                        <tr>
                            <th>Lead</th>
                            <th>Point of Lead</th>
                            <th>Status</th>
                            <th>Created date</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if(!empty($leads)): ?>
                            <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="lead__ref-info">
                                        <a href="<?php echo e(route('leads.show', $lead->id)); ?>">
                                            <?php echo e($lead->fullname); ?>

                                            <span><?php echo e($lead->product); ?></span>
                                        </a>
                                    </td>
                                    <td class="lead__ref-point" width="110"><?php echo e($lead->point); ?></td>
                                    <td class="lead__ref-status">
                                        <span class="label-status <?php echo e(Common::showColorStatus($lead->status)); ?>"><?php echo e($lead->statusLead); ?></span>
                                    </td>
                                    <td class="lead__ref-date"><?php echo e($lead->create); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="3">Do not have any tipster.</td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                        <tfoot>
                        <tr>
                            <th>Lead</th>
                            <th>Point of Lead</th>
                            <th>Status</th>
                            <th>Created date</th>
                        </tr>
                        </tfoot>

                    </table>
                </div>
            </div>
        </div>
        <!-- /.col -->
    </div>
    
    <div id="popup-confirm" class="modal popup-confirm" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <p>Do you really want to delete tipster "<?php echo e($user->fullname); ?>" ?</p>
                    <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Cancel</button>
                    <?php if($deleteAction == true): ?><form class="inline" action="<?php echo e(action('TipstersController@destroy', $user->id)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input name="_method" type="hidden" value="DELETE">
                        <button class="btn btn-sm btn-danger" type="submit">Yes</button>
                    </form><?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>