<?php if($paginator->count() > 0): ?>1 <?php else: ?> 0 <?php endif; ?> -<?php echo e($paginator->count()); ?>/<?php echo e($paginator->total()); ?>


    <div class="btn-group">

        <?php if($paginator->onFirstPage()): ?>
            <a rel="prev" class="btn btn-default btn-sm disabled"><i class="fa fa-chevron-left"></i></a>
        <?php else: ?>
            <a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" class="btn btn-default btn-sm">
                <i class="fa fa-chevron-left"></i>
            </a>
        <?php endif; ?>

        <?php if($paginator->hasMorePages()): ?>
            <a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" class="btn btn-default btn-sm">
                <i class="fa fa-chevron-right"></i>
            </a>
        <?php else: ?>
            <a rel="next" class="btn btn-default btn-sm disabled"><i class="fa fa-chevron-right"></i></a>
        <?php endif; ?>
    </div>

