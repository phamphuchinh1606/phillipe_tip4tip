-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 02, 2018 at 08:42 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tip4tipsv1.2`
--

-- --------------------------------------------------------

--
-- Table structure for table `actions`
--

CREATE TABLE `actions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `actions`
--

INSERT INTO `actions` (`id`, `name`, `code`, `created_at`, `updated_at`) VALUES
(1, 'Create', 'create', NULL, NULL),
(2, 'edit', 'Edit', NULL, NULL),
(3, 'View', 'view', NULL, NULL),
(4, 'Delete', 'delete', NULL, NULL),
(5, 'List', 'list', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `assignments`
--

CREATE TABLE `assignments` (
  `id` int(10) UNSIGNED NOT NULL,
  `consultant_id` int(10) UNSIGNED NOT NULL,
  `lead_id` int(10) UNSIGNED NOT NULL,
  `create_by` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `assignments`
--

INSERT INTO `assignments` (`id`, `consultant_id`, `lead_id`, `create_by`, `created_at`, `updated_at`) VALUES
(1, 10, 8, 1, '2018-01-18 01:07:04', '2018-02-06 02:59:20'),
(2, 7, 1, 1, '2018-01-22 00:04:03', '2018-01-22 00:04:03'),
(3, 6, 1, 1, '2018-01-23 05:26:38', '2018-01-23 05:26:38'),
(4, 7, 1, 1, '2018-01-23 05:35:32', '2018-01-23 05:35:32'),
(5, 6, 1, 1, '2018-01-23 05:36:04', '2018-01-23 05:36:04'),
(6, 7, 1, 1, '2018-01-23 05:46:23', '2018-01-23 05:46:23'),
(7, 6, 1, 1, '2018-01-23 19:37:50', '2018-01-23 19:37:50'),
(8, 6, 1, 8, '2018-01-23 20:11:06', '2018-01-23 20:11:06'),
(10, 7, 4, 1, '2018-01-26 02:35:25', '2018-01-26 02:35:25'),
(11, 7, 1, 1, '2018-01-26 02:45:51', '2018-01-26 02:45:51'),
(12, 7, 1, 1, '2018-01-29 23:33:03', '2018-01-29 23:33:03'),
(13, 10, 7, 1, '2018-01-30 03:02:33', '2018-01-30 03:02:33'),
(14, 6, 7, 1, '2018-01-31 02:05:06', '2018-01-31 02:05:06'),
(15, 7, 7, 1, '2018-01-31 04:29:26', '2018-01-31 04:29:26'),
(16, 7, 27, 1, '2018-02-07 04:26:29', '2018-02-07 04:26:29'),
(17, 6, 31, 1, '2018-02-08 00:50:34', '2018-02-08 00:50:34'),
(18, 10, 14, 1, '2018-02-09 02:16:47', '2018-02-09 02:16:47'),
(19, 10, 33, 6, '2018-02-28 03:30:20', '2018-02-28 03:30:20');

-- --------------------------------------------------------

--
-- Table structure for table `evaluationautos`
--

CREATE TABLE `evaluationautos` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `create_by` int(10) UNSIGNED NOT NULL,
  `person_is` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `giftcategories`
--

CREATE TABLE `giftcategories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `giftcategories`
--

INSERT INTO `giftcategories` (`id`, `name`, `code`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Electronic', '', NULL, '2018-01-16 22:06:26', '2018-01-16 22:06:26'),
(2, 'Electronic', 'electronic', NULL, NULL, NULL),
(3, 'House tool', 'housetool', NULL, NULL, NULL),
(4, 'Accessories', 'accessories', NULL, NULL, NULL),
(6, 'Bags', 'bags', NULL, NULL, NULL),
(7, 'Bikes & Cars', 'bikes&cars', NULL, NULL, NULL),
(8, 'Clothes', 'clothes', NULL, NULL, NULL),
(9, 'Cosmetics', 'cosmetics', NULL, NULL, NULL),
(10, 'Entertaiment', 'entertaiment', NULL, NULL, NULL),
(11, 'Fine Foods', 'finefoods', NULL, NULL, NULL),
(12, 'Furniture', 'furniture', NULL, NULL, NULL),
(13, 'High Tech', 'hightech', NULL, NULL, NULL),
(14, 'House Ware', 'houseware', NULL, NULL, NULL),
(15, 'Jewels', 'jewels', NULL, NULL, NULL),
(16, 'Medical', 'medical', NULL, NULL, NULL),
(17, 'Sport items', 'sportitems', NULL, NULL, NULL),
(18, 'Travel', 'travel', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `gifts`
--

CREATE TABLE `gifts` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `point` decimal(8,0) NOT NULL DEFAULT '0',
  `category_id` int(10) UNSIGNED NOT NULL,
  `thumbnail` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delete_is` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gifts`
--

INSERT INTO `gifts` (`id`, `name`, `description`, `point`, `category_id`, `thumbnail`, `delete_is`, `created_at`, `updated_at`) VALUES
(4, 'Fridge', 'Ea soluta script Altera inciderint te has, his postea vidisse probatus an. Sea eruditi tractatos et.', '500', 1, '1518514197.jpg', 0, '2018-01-16 22:07:29', '2018-02-28 21:25:54'),
(5, '323123', 'werwsds', '32', 6, '1518514679.png', 0, '2018-02-13 02:38:19', '2018-02-28 21:25:05'),
(6, 'gift test', NULL, '0', 16, 'no_image_available.jpg', 1, '2018-02-28 20:17:00', '2018-02-28 21:28:42');

-- --------------------------------------------------------

--
-- Table structure for table `leadprocesses`
--

CREATE TABLE `leadprocesses` (
  `id` int(10) UNSIGNED NOT NULL,
  `lead_id` int(10) UNSIGNED NOT NULL,
  `status_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `leadprocesses`
--

INSERT INTO `leadprocesses` (`id`, `lead_id`, `status_id`, `created_at`, `updated_at`) VALUES
(65, 11, 2, '2018-02-02 00:18:05', '2018-02-02 00:18:05'),
(66, 11, 3, '2018-02-02 00:18:10', '2018-02-02 00:18:10'),
(67, 9, 2, '2018-02-02 00:18:56', '2018-02-02 00:18:56'),
(68, 9, 3, '2018-02-02 00:19:00', '2018-02-02 00:19:00'),
(69, 6, 3, '2018-02-02 00:20:39', '2018-02-02 00:20:39'),
(70, 19, 1, '2018-02-05 03:11:12', '2018-02-05 03:11:12'),
(71, 19, 2, '2018-02-05 03:11:44', '2018-02-05 03:11:44'),
(72, 18, 1, '2018-02-05 20:46:10', '2018-02-05 20:46:10'),
(73, 26, 3, '2018-02-06 05:36:21', '2018-02-06 05:36:21'),
(74, 23, 2, '2018-02-07 00:36:33', '2018-02-07 00:36:33'),
(75, 22, 4, '2018-02-07 00:36:48', '2018-02-07 00:36:48'),
(76, 21, 1, '2018-02-07 00:37:04', '2018-02-07 00:37:04'),
(77, 21, 3, '2018-02-07 00:37:09', '2018-02-07 00:37:09'),
(78, 17, 1, '2018-02-07 00:37:29', '2018-02-07 00:37:29'),
(79, 27, 3, '2018-02-07 04:26:42', '2018-02-07 04:26:42'),
(80, 23, 3, '2018-02-07 04:30:05', '2018-02-07 04:30:05'),
(81, 29, 1, '2018-02-08 00:07:14', '2018-02-08 00:07:14'),
(82, 29, 3, '2018-02-08 00:07:17', '2018-02-08 00:07:17'),
(83, 28, 3, '2018-02-08 00:09:24', '2018-02-08 00:09:24'),
(84, 20, 3, '2018-02-08 00:18:27', '2018-02-08 00:18:27'),
(85, 32, 3, '2018-02-08 00:42:42', '2018-02-08 00:42:42'),
(86, 31, 3, '2018-02-08 00:50:42', '2018-02-08 00:50:42'),
(87, 30, 1, '2018-02-08 02:21:54', '2018-02-08 02:21:54'),
(88, 30, 2, '2018-02-08 02:26:09', '2018-02-08 02:26:09');

-- --------------------------------------------------------

--
-- Table structure for table `leads`
--

CREATE TABLE `leads` (
  `id` int(10) UNSIGNED NOT NULL,
  `fullname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` tinyint(4) NOT NULL,
  `birthday` date DEFAULT '1900-01-01',
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `tipster_id` int(10) UNSIGNED NOT NULL,
  `region_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `leads`
--

INSERT INTO `leads` (`id`, `fullname`, `gender`, `birthday`, `address`, `email`, `phone`, `notes`, `product_id`, `status`, `tipster_id`, `region_id`, `created_at`, `updated_at`) VALUES
(1, 'Nguyen Ngọc Hân', 1, '2000-08-19', NULL, 'lead1@gmail.com', '0192837743', 'Urgent', 6, 0, 4, 2, '2018-01-16 22:18:32', '2018-01-30 23:50:24'),
(4, 'Pham Thi Ly', 0, NULL, '11', 'lypham@gmail.com', '0962198273', NULL, 10, 0, 2, 2, '2018-01-23 00:37:46', '2018-01-30 04:09:11'),
(7, 'Phạm Phú Thứ', 0, NULL, NULL, 'phuthu@gmail.com', '0192318623', 'Urgent', 4, 0, 2, 1, '2018-01-30 02:46:53', '2018-02-01 03:28:06'),
(8, 'Pham Thi Dang Thuy', 1, NULL, NULL, NULL, '0989310732', NULL, 4, 0, 2, 1, '2018-01-31 20:39:28', '2018-02-01 03:27:20'),
(10, 'Pham Thi Dang Thuy', 1, NULL, NULL, NULL, '0989310732', NULL, 4, 0, 2, 1, '2018-01-31 20:57:21', '2018-02-01 03:02:43'),
(11, 'Tran Thu Ha', 1, NULL, NULL, NULL, '03920382947', 'URGENT', 4, 3, 5, 1, '2018-01-31 21:36:44', '2018-02-02 00:18:10'),
(12, 'Nguyen Mong Kieu', 1, NULL, NULL, NULL, '0390129887', NULL, 8, 0, 11, 2, '2018-02-04 21:21:07', '2018-02-04 21:21:07'),
(13, 'Ha Tran Minh Anh', 0, NULL, NULL, 'minhanh@gmail.com', NULL, 'urgent', 6, 0, 2, 3, '2018-02-04 21:24:28', '2018-02-04 21:24:28'),
(14, 'Pham Dang Thuy', 0, NULL, NULL, '1212@gmail.com', '12212', 'sdfsdf', 4, 0, 2, 1, '2018-02-05 02:41:23', '2018-02-05 02:41:23'),
(20, 'Trần Đại Nhân Nghĩa', 0, NULL, NULL, NULL, NULL, NULL, 5, 3, 2, 2, '2018-02-06 03:33:47', '2018-02-08 00:18:28'),
(21, 'Nguyễn Phạm Duy Hậu', 0, NULL, NULL, NULL, NULL, NULL, 5, 3, 3, 2, '2018-02-06 03:43:39', '2018-02-07 00:37:09'),
(26, 'Nguyễn Minh Hùng', 0, NULL, NULL, NULL, '09038921387', NULL, 7, 3, 4, 2, '2018-02-06 04:05:31', '2018-02-07 20:05:17'),
(27, 'Phạm Trần Nhật Kỳ', 0, NULL, NULL, NULL, '0930183872', NULL, 8, 3, 5, 2, '2018-02-06 06:04:25', '2018-02-07 04:26:42'),
(28, 'Trần Bảo Bình', 0, NULL, NULL, NULL, '9308109238', NULL, 4, 3, 11, 1, '2018-02-07 21:24:39', '2018-02-08 00:09:25'),
(29, 'Nguyễn Hà Như Thanh', 1, NULL, NULL, 'nhuthanh@gmail.com', '738178982', NULL, 7, 3, 11, 1, '2018-02-07 21:25:09', '2018-02-08 19:59:28'),
(30, 'Đỗ Đồng Văn', 0, NULL, NULL, NULL, '0398978962', NULL, 6, 2, 16, 2, '2018-02-08 00:25:39', '2018-02-08 02:26:09'),
(31, 'Khổng Tú Quỳnh', 1, NULL, NULL, 'quynhkhongtu@gmail.com', '098766565', NULL, 6, 3, 12, 2, '2018-02-08 00:26:30', '2018-02-08 19:58:35'),
(32, 'Ngô Kiến Huy', 0, NULL, NULL, 'huykienngoobap@gmail.com', '0939178665', NULL, 9, 3, 5, 2, '2018-02-08 00:27:14', '2018-02-08 19:56:54'),
(33, 'Lê Thị Hông Phúc', 1, NULL, NULL, 'lehongphuc@gmail.com', '098736572', NULL, 9, 0, 11, 2, '2018-02-11 21:06:25', '2018-02-11 21:06:25'),
(34, 'Nguyễn Ngọc Ngạn', 0, NULL, NULL, NULL, '09989766612', NULL, 4, 0, 3, 1, '2018-03-01 20:19:44', '2018-03-01 20:19:44');

-- --------------------------------------------------------

--
-- Table structure for table `log_activities`
--

CREATE TABLE `log_activities` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `affected_object` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `action` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `log_activities`
--

INSERT INTO `log_activities` (`id`, `user_id`, `affected_object`, `action`, `description`, `created_at`, `updated_at`) VALUES
(20, 1, 'Tipster', 'Created', 'Created Tipster : Phạm Thị Minh Tuyết', '2018-02-06 06:03:32', '2018-02-06 06:03:32'),
(21, 1, 'Lead', 'Created', 'Created Lead : Phạm Trần Nhật Kỳ', '2018-02-04 06:04:25', '2018-02-06 06:04:25'),
(22, 1, 'Lead', 'Update', 'Update Lead', '2018-02-06 06:16:03', '2018-02-06 06:16:03'),
(23, 1, 'Lead', 'Update', 'Update Lead', '2018-02-05 00:36:26', '2018-02-07 00:36:26'),
(26, 1, 'Lead', 'Update', 'Update Lead', '2018-02-07 00:37:15', '2018-02-07 00:37:15'),
(27, 1, 'Lead', 'Update', 'Update Lead', '2018-02-07 00:37:23', '2018-02-07 00:37:23'),
(28, 1, 'Lead', 'Update', 'Update Lead', '2018-02-07 00:55:12', '2018-02-07 00:55:12'),
(29, 1, 'Lead', 'Update', 'Update Lead : Update Points', '2018-02-07 04:26:49', '2018-02-07 04:26:49'),
(31, 1, 'Lead', 'Created', 'Created Lead : Trần Bảo Bình', '2018-02-07 21:24:39', '2018-02-07 21:24:39'),
(32, 1, 'Lead', 'Created', 'Created Lead : Nguyễn Hà Như Thanh', '2018-02-07 21:25:09', '2018-02-07 21:25:09'),
(33, 1, 'Lead', 'Update points', 'Update points Lead : Nguyễn Hà Như Thanh', '2018-02-08 00:07:24', '2018-02-08 00:07:24'),
(34, 1, 'Lead', 'Update points', 'Update points Lead : Trần Bảo Bình', '2018-02-08 00:09:43', '2018-02-08 00:09:43'),
(36, 1, 'Lead', 'Created', 'Created Lead : Đỗ Đồng Văn', '2018-02-08 00:25:39', '2018-02-08 00:25:39'),
(37, 1, 'Lead', 'Created', 'Created Lead : Khổng Tú Quỳnh', '2018-02-08 00:26:29', '2018-02-08 00:26:29'),
(38, 1, 'Lead', 'Created', 'Created Lead : Ngô Kiến Huy', '2018-02-08 00:27:14', '2018-02-08 00:27:14'),
(39, 1, 'Tipster', 'Update points', 'Update points Tipster : Ngô Kiến Huy', '2018-02-08 00:42:52', '2018-02-08 00:42:52'),
(40, 1, 'Tipster', 'Update points for', 'Update points for Tipster : Nguyễn Chất Hiển', '2018-02-08 00:50:55', '2018-02-08 00:50:55'),
(43, 1, 'Lead', 'Created', 'Created Lead : Ngô Kiến Huy', '2018-02-08 19:56:54', '2018-02-08 19:56:54'),
(44, 1, 'Lead', 'Created', 'Created Lead : Khổng Tú Quỳnh', '2018-02-08 19:58:35', '2018-02-08 19:58:35'),
(45, 1, 'Lead', 'Update', 'Update Lead : Nguyễn Hà Như Thanh', '2018-02-08 19:59:28', '2018-02-08 19:59:28'),
(46, 1, 'Lead', 'Update', 'Update Lead : Phạm Thị Minh Tuyết', '2018-02-08 20:31:03', '2018-02-08 20:31:03'),
(47, 1, 'Tipster', 'update', 'update Tipster : Admin', '2018-02-08 20:49:33', '2018-02-08 20:49:33'),
(48, 1, 'Lead', 'delete', 'delete Lead', '2018-02-08 21:08:00', '2018-02-08 21:08:00'),
(49, 1, 'Lead', 'delete', 'delete Lead : 6', '2018-02-08 21:08:48', '2018-02-08 21:08:48'),
(50, 1, 'Lead', 'delete', 'delete Lead : lead 6', '2018-02-08 21:10:08', '2018-02-08 21:10:08'),
(51, 1, 'Lead', 'delete', 'delete Lead : Nguyễn Phạm Duy Hậu111', '2018-02-08 21:10:46', '2018-02-08 21:10:46'),
(52, 1, 'Tipster', 'update', 'update Tipster : Trần Thị Bích Lài', '2018-02-08 21:21:44', '2018-02-08 21:21:44'),
(53, 1, 'Community Manager', 'update', 'update Community Manager : Community Manager', '2018-02-08 21:23:36', '2018-02-08 21:23:36'),
(54, 1, 'Gift', 'created', 'created Gift : Gift test', '2018-02-08 21:28:01', '2018-02-08 21:28:01'),
(55, 1, 'Gift', 'delete', 'delete Gift : Gift test', '2018-02-08 21:28:15', '2018-02-08 21:28:15'),
(56, 1, 'User', 'created', 'created User : Phùng Khắc Khoan', '2018-02-09 00:12:42', '2018-02-09 00:12:42'),
(57, 1, 'User', 'delete', 'delete User : Consultant Thuy', '2018-02-09 00:27:02', '2018-02-09 00:27:02'),
(58, 1, 'User', 'delete', 'delete User : Consultant Thuy', '2018-02-09 00:28:41', '2018-02-09 00:28:41'),
(59, 1, 'Tipster', 'created', 'created Tipster : Nguyễn Hà Anh', '2018-02-09 00:33:47', '2018-02-09 00:33:47'),
(60, 1, 'Tipster', 'update', 'update Tipster : Nguyễn Hà Anh', '2018-02-09 03:55:15', '2018-02-09 03:55:15'),
(61, 1, 'Tipster', 'update', 'update Tipster : Nguyễn Hà Anh', '2018-02-09 04:18:28', '2018-02-09 04:18:28'),
(62, 1, 'Tipster', 'update', 'update Tipster : Nguyễn Hà Anh', '2018-02-09 04:39:34', '2018-02-09 04:39:34'),
(63, 1, 'Tipster', 'created', 'created Tipster : Trần Hòa B', '2018-02-09 04:51:52', '2018-02-09 04:51:52'),
(64, 1, 'Tipster', 'update', 'update Tipster : Nguyễn Chất Hiển', '2018-02-11 20:40:14', '2018-02-11 20:40:14'),
(65, 1, 'Lead', 'created', 'created Lead : Lê Thị Hông Phúc', '2018-02-11 21:06:24', '2018-02-11 21:06:24'),
(66, 1, 'Community Manager', 'update', 'update Community Manager : Community Manager', '2018-02-12 20:58:03', '2018-02-12 20:58:03'),
(67, 1, 'Community Manager', 'update', 'update Community Manager : Admin', '2018-02-12 21:00:34', '2018-02-12 21:00:34'),
(68, 1, 'Community Manager', 'update', 'update Community Manager : Phùng Khắc Khoan', '2018-02-12 21:08:43', '2018-02-12 21:08:43'),
(69, 1, 'Community Manager', 'update', 'update Community Manager : Bui Quang H', '2018-02-12 21:11:06', '2018-02-12 21:11:06'),
(70, 1, 'Gift', 'update', 'update Gift : Fridge', '2018-02-13 00:10:44', '2018-02-13 00:10:44'),
(71, 1, 'Gift', 'update', 'update Gift : Fridge', '2018-02-13 00:21:15', '2018-02-13 00:21:15'),
(72, 1, 'Gift', 'update', 'update Gift : Fridge', '2018-02-13 02:30:03', '2018-02-13 02:30:03'),
(73, 1, 'Gift', 'created', 'created Gift', '2018-02-13 02:33:07', '2018-02-13 02:33:07'),
(74, 1, 'Gift', 'created', 'created Gift', '2018-02-13 02:33:17', '2018-02-13 02:33:17'),
(75, 1, 'Gift', 'created', 'created Gift : 323123', '2018-02-13 02:38:18', '2018-02-13 02:38:18'),
(76, 1, 'Product', 'update', 'update Product : Medical', '2018-02-26 02:49:36', '2018-02-26 02:49:36'),
(77, 1, 'Lead', 'delete', 'delete Lead : Pham Dang Thuy', '2018-02-26 20:52:25', '2018-02-26 20:52:25'),
(78, 1, 'Lead', 'delete', 'delete Lead : Pham Dang Thuy', '2018-02-26 20:53:57', '2018-02-26 20:53:57'),
(79, 1, 'Community Manager', 'update', 'update Community Manager : Sale Manager', '2018-02-27 03:31:32', '2018-02-27 03:31:32'),
(80, 8, 'Community Manager', 'update', 'update Community Manager : Ha Chi T', '2018-02-28 02:54:05', '2018-02-28 02:54:05'),
(81, 8, 'Community Manager', 'update', 'update Community Manager : Sale Manager', '2018-02-28 02:55:25', '2018-02-28 02:55:25'),
(82, 8, 'Community Manager', 'update', 'update Community Manager : Sale Manager', '2018-02-28 03:10:39', '2018-02-28 03:10:39'),
(83, 6, 'Community Manager', 'update', 'update Community Manager : Consultant Thuy', '2018-02-28 03:22:50', '2018-02-28 03:22:50'),
(84, 6, 'Community Manager', 'update', 'update Community Manager : Consultant Thuy', '2018-02-28 03:23:16', '2018-02-28 03:23:16'),
(85, 6, 'Community Manager', 'update', 'update Community Manager : Consultant Thuy', '2018-02-28 03:24:53', '2018-02-28 03:24:53'),
(86, 6, 'Community Manager', 'update', 'update Community Manager : Consultant Thuy', '2018-02-28 03:25:16', '2018-02-28 03:25:16'),
(87, 6, 'Community Manager', 'update', 'update Community Manager : Consultant Thuy', '2018-02-28 03:28:28', '2018-02-28 03:28:28'),
(88, 6, 'Community Manager', 'update', 'update Community Manager : Consultant Thuy', '2018-02-28 03:28:51', '2018-02-28 03:28:51'),
(89, 6, 'Community Manager', 'update', 'update Community Manager : Consultant Thuy', '2018-02-28 03:29:27', '2018-02-28 03:29:27'),
(90, 1, 'Community Manager', 'update', 'update Community Manager : Admin', '2018-02-28 03:49:54', '2018-02-28 03:49:54'),
(91, 1, 'Product', 'created', 'created Product : test', '2018-02-28 20:12:20', '2018-02-28 20:12:20'),
(92, 1, 'Gift', 'created', 'created Gift : gift test', '2018-02-28 20:15:17', '2018-02-28 20:15:17'),
(93, 1, 'Gift', 'created', 'created Gift : gift test', '2018-02-28 20:17:00', '2018-02-28 20:17:00'),
(94, 1, 'Gift', 'delete', 'delete Gift : gift test', '2018-02-28 20:21:04', '2018-02-28 20:21:04'),
(95, 1, 'Product', 'delete', 'delete Product : test', '2018-02-28 21:11:58', '2018-02-28 21:11:58'),
(96, 1, 'Gift', 'delete', 'delete Gift : 323123', '2018-02-28 21:25:05', '2018-02-28 21:25:05'),
(97, 1, 'Gift', 'delete', 'delete Gift : Fridge', '2018-02-28 21:25:53', '2018-02-28 21:25:53'),
(98, 1, 'Gift', 'delete', 'delete Gift : gift test', '2018-02-28 21:28:42', '2018-02-28 21:28:42'),
(99, 1, 'Product', 'delete', 'delete Product : Shops', '2018-02-28 21:29:54', '2018-02-28 21:29:54'),
(100, 1, 'Product', 'created', 'created Product : Shop', '2018-02-28 21:51:44', '2018-02-28 21:51:44'),
(101, 1, 'Product', 'update', 'update Product : Shop', '2018-02-28 21:52:08', '2018-02-28 21:52:08'),
(102, 1, 'Tipster', 'update', 'update Tipster : Trần Hòa B', '2018-03-01 03:28:56', '2018-03-01 03:28:56'),
(103, 1, 'Tipster', 'created', 'created Tipster : Tipster 321', '2018-03-01 03:30:39', '2018-03-01 03:30:39'),
(104, 1, 'Tipster', 'created', 'created Tipster : tipster 321', '2018-03-01 03:41:10', '2018-03-01 03:41:10'),
(105, 1, 'User', 'delete', 'delete User : Bui Quang H', '2018-03-01 19:34:38', '2018-03-01 19:34:38'),
(106, 1, 'Community Manager', 'update', 'update Community Manager : Community Manager', '2018-03-01 19:39:06', '2018-03-01 19:39:06'),
(107, 1, 'Community Manager', 'update', 'update Community Manager : Sale Manager', '2018-03-01 19:39:14', '2018-03-01 19:39:14'),
(108, 1, 'Community Manager', 'update', 'update Community Manager : Phùng Khắc Khoan', '2018-03-01 19:39:20', '2018-03-01 19:39:20'),
(109, 1, 'Community Manager', 'update', 'update Community Manager : Bui Quang H', '2018-03-01 19:39:26', '2018-03-01 19:39:26'),
(110, 1, 'Community Manager', 'update', 'update Community Manager : Ha Chi T', '2018-03-01 19:39:35', '2018-03-01 19:39:35'),
(111, 1, 'User', 'delete', 'delete User : Ha Chi T', '2018-03-01 19:41:11', '2018-03-01 19:41:11'),
(112, 3, 'Lead', 'created', 'created Lead : Nguyễn Ngọc Ngạn', '2018-03-01 20:19:44', '2018-03-01 20:19:44'),
(113, 1, 'Tipster', 'update', 'update Tipster : Nguyễn Hà Mỹ Ngọc', '2018-03-01 23:28:54', '2018-03-01 23:28:54');

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `author` int(10) UNSIGNED DEFAULT NULL,
  `receiver` int(10) UNSIGNED NOT NULL,
  `delete_is` tinyint(4) NOT NULL DEFAULT '0',
  `delete_sent` tinyint(1) DEFAULT '0',
  `delete_trash` tinyint(1) DEFAULT '0',
  `read_is` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `title`, `content`, `author`, `receiver`, `delete_is`, `delete_sent`, `delete_trash`, `read_is`, `created_at`, `updated_at`) VALUES
(1, 'Test mail', '<p>rtertert</p>', 1, 2, 0, 0, 0, 0, '2018-01-24 04:50:36', '2018-01-24 20:16:25'),
(2, 'ewewr', '<p>rwerwer</p>', 1, 2, 0, 0, 0, 0, '2018-01-24 04:50:48', '2018-03-01 02:16:20'),
(3, 'You may also pass', '<p>Dicant oporteat torquatos ad nam. Per invidunt oportere ex. Ut vix dicam antiopam neglegentur, at duo ornatus fuisset delectus. Nibh cibo persecuti ad vis. Errem nonumy sit et. Tation necessitatibus per te, id quot bonorum laoreet mel. Quo iusto hendrerit mediocritatem te, et est saperet meliore theophrastus.<br></p>', 2, 3, 0, 0, 0, 0, '2018-01-24 20:21:17', '2018-01-24 20:21:17'),
(4, 'Asia/Ho_Chi_Minh', '<p>fasfasfasf</p>', 3, 2, 0, 0, 0, 0, '2018-01-24 21:30:39', '2018-01-24 21:30:39'),
(5, 'Dicant oporteat torquatos ad nam', '<p>Sed ut harum aliquando. Modus novum complectitur nam in, aperiri admodum eu nec. His vero justo honestatis cu, vis reque appareat partiendo at, senserit efficiantur mel cu. Labores eleifend appellantur sit te.<br><br>No amet ponderum tractatos usu, sea consulatu philosophia in. Eum sonet dicam assentior ei, et quo noster inermis indoctum. Et has fastidii deleniti tractatos, reque habemus moderatius no nec. Est vitae libris albucius te, mei altera adipiscing ut, possim equidem mei ei. Timeam lobortis necessitatibus et sed, purto probo per at.<br></p>', 1, 3, 1, 1, 1, 0, '2018-01-25 00:53:43', '2018-03-01 21:36:54'),
(6, 'test 1', '<p>Idque labores epicuri vis eu, eu eligendi consectetuer mel. Veritus omittantur duo ut, apeirian reprehendunt ei cum. Eu cum legere vivendum, error iudico possit ei has, in agam aperiam patrioque duo. Usu no veritus ocurreret referrentur. Ipsum omittam probatus pri cu.<br></p>', 1, 2, 0, 0, 0, 0, '2018-03-01 00:39:03', '2018-03-01 02:11:06'),
(7, 'Dicant oporteat torquatos ad nam', '<p>Idque labores epicuri vis eu, eu eligendi consectetuer mel. Veritus omittantur duo ut, apeirian reprehendunt ei cum. Eu cum legere vivendum, error iudico possit ei has, in agam aperiam patrioque duo. Usu no veritus ocurreret referrentur. Ipsum omittam probatus pri cu.<br></p>', 1, 5, 0, 0, 0, 0, '2018-03-01 00:39:25', '2018-03-01 02:06:34'),
(8, 'You called lead?', '<p>Idque labores epicuri vis eu, eu eligendi consectetuer mel. Veritus omittantur duo ut, apeirian reprehendunt ei cum. Eu cum legere vivendum, error iudico possit ei has, in agam aperiam patrioque duo. Usu no veritus ocurreret referrentur. Ipsum omittam probatus pri cu.<br></p>', 1, 4, 0, 0, 0, 0, '2018-03-01 00:39:56', '2018-03-01 02:06:19'),
(9, 'Urgent', '<p>Lorem ipsum dolor sit amet, at mel debet volutpat, eu nam elit interesset temporibus, ne pri rationibus complectitur. Te utamur iuvaret vivendum eam, ut clita imperdiet vix. Ut dicta postulant aliquando quo, ad ius nostro discere, et sea senserit electram. Id nec nostro option singulis, ferri atqui gloriatur at pri. Mea enim ullum te.<br><br>Idque labores epicuri vis eu, eu eligendi consectetuer mel. Veritus omittantur duo ut, apeirian reprehendunt ei cum. Eu cum legere vivendum, error iudico possit ei has, in agam aperiam patrioque duo. Usu no veritus ocurreret referrentur. Ipsum omittam probatus pri cu.<br><br>Ad dolorem inciderint his, vim ad admodum invidunt dissentiunt, vis id nulla vivendo postulant. Eu elit facer ornatus pri, quas exerci accumsan usu te. Enim gloriatur no quo, ea minim paulo lucilius ius. Tation dicant iudicabit no est, alia appetere ea mel, mea vero liber inermis eu. Veri disputationi vel eu, mollis nusquam verterem sit ne.<br><br>Nibh sonet eum ne, offendit invenire explicari sed cu. Mei ei malis partem, simul tation debitis sed ne. Eum novum feugait ut, sumo cotidieque deterruisset eam ut. Eu legere dicunt ocurreret mea, quo odio elitr dicant ne.<br><br>Vel no agam laudem. Ut nec atqui melius audiam, eam enim sonet nusquam cu. Nonumy iisque repudiare eum eu, persecuti philosophia nec eu. Mea amet partem at, timeam laboramus quo eu. At nec graece dolorum ponderum, commune imperdiet ut sit.<br></p>', 1, 5, 0, 1, 0, 0, '2018-03-01 00:40:32', '2018-03-01 02:28:30'),
(10, 'hfijsh fjsd hfjs dhfjhs df', '<p>Ei qui persius deleniti, aliquip aliquando quo no, qui at option impedit. Sea clita indoctum an, eum case luptatum tacimates id. Eum te dissentias temporibus, nec etiam tritani dolorum at. Ubique numquam ne his. Possim iudicabit cum eu, eum ne eruditi oporteat, oporteat voluptatum eos ea.<br><br>Vim justo corrumpit assentior at, has falli feugiat percipitur ei. Modus posse ea eam, sit iracundia persequeris te. Vide facer labore ex sit, sumo sint malis no nec, eu expetenda contentiones sea. Tempor elaboraret qui te, id vim ubique virtute similique, quidam semper efficiendi pri ei.<br><br>Ad laoreet petentium interesset cum, modo iisque mandamus sea at. Est suas mediocrem forensibus no, brute oportere accusamus vel ne. Per eu alii laudem maluisset, no vis instructior definitiones. Cibo tation melius in sea, vis nemore lobortis assueverit eu, in fuisset volutpat sea. Ullum semper principes ne cum, sea no sensibus eleifend accommodare, te tollit assueverit eos.<br><br>Duo omnis virtute meliore ut, ut scaevola elaboraret mei. Viris quodsi te sea. Mea ad iusto simul dolorum. No pro quod oporteat, ad lucilius conceptam per, mel appetere apeirian no. Ne nostrud equidem volumus quo, vel ne fabellas concludaturque, vel te appareat platonem.<br><br>Nemore partiendo ad est. Cu modus integre referrentur quo. Sit ad reque audiam minimum, saperet vituperata usu in, pro id iudico principes. Te has nonumes tractatos, ei vel sumo corrumpit. Sit ei aeque liberavisse. Contentiones vituperatoribus no usu, vel no quas suavitate, qui ne duis veri ubique.<br><br>In tollit eripuit intellegebat vix. In verterem periculis ius, et per singulis praesent contentiones, sit corrumpit reprehendunt cu. Pro nisl libris persecuti ut, putant definitionem ut mea. Est no eros veri percipit. An mei deseruisse intellegam, ei eum vocibus mediocritatem, qui at agam tantas perfecto. Eam elaboraret repudiandae suscipiantur at, ea mnesarchum suscipiantur est, vel ea munere regione intellegam.<br><br>Referrentur efficiantur mediocritatem no per. No aperiam officiis convenire qui. Mea vidit prima referrentur ea. Cu sit verear urbanitas. Ullum admodum ullamcorper nam an. Saepe aeterno meliore eu vel.<br><br>Omnes officiis eum te, ne munere definitionem eum. Vis quis vero regione cu, his luptatum deseruisse cu, ipsum aliquid saperet eum ei. Ea vitae mandamus vis, pro ea principes corrumpit. In nullam interpretaris sea. Viderer phaedrum referrentur vel ea. Ut nam doming consulatu.<br><br>Sit te aliquip denique. Veniam epicuri expetenda et pri. Eu mel detracto tractatos scripserit, pri rebum pertinax an. Laboramus voluptaria in vel, possit singulis sententiae in vis. Mei id erant minimum, hinc etiam convenire in nec. Sea id suas graece.<br><br>Ut minim scaevola nam. Melius placerat mei ad, vel id amet torquatos. Posse facer corpora et sit. No sed vivendo facilisi inimicus, qui vidit eligendi te, te hinc inani mel. Ei usu falli nominavi, ea unum possim temporibus pro, ne hinc nominati vis. An rebum viris suscipiantur cum, mutat argumentum at eos, illud recusabo dissentiet ei eos. Accusam recteque in qui.<br></p>', 1, 2, 1, 0, 0, 0, '2018-03-01 01:11:11', '2018-03-01 02:21:21'),
(11, 'why do you contact with you manager', '<p>dwdsad</p>', 1, 3, 0, 0, 0, 0, '2018-03-01 20:54:47', '2018-03-01 20:54:47'),
(12, 'I don\'t contact with my manager', '<p>sdasda</p>', 3, 1, 1, 0, 0, 1, '2018-03-01 20:55:23', '2018-03-01 21:28:33'),
(13, 'Can you contact with my manager?', '<p>ddasdasd</p>', 3, 1, 0, 0, 0, 1, '2018-03-01 21:14:09', '2018-03-01 21:27:48'),
(14, 'dasdas', '<p>dsfsdfsdf</p>', 1, 3, 0, 0, 0, 0, '2018-03-01 21:41:24', '2018-03-01 21:41:24'),
(15, 'sfsfsd', '<p>fsdfsdf</p>', 1, 3, 0, 0, 0, 0, '2018-03-01 21:41:36', '2018-03-01 21:41:36'),
(16, 'Do you call your manager?', '<p>Ea mei mutat debet solet. Ei utinam voluptatibus mei, amet qualisque vix ex. Nibh feugait cu nam, id per aliquando forensibus. Ex consequat vituperata duo. Ut vim quem quot, detraxit interpretaris duo ad. Mei dolores pertinax delicatissimi eu, eu sit esse ubique salutandi. Ea his vero veri.<br><br>Eum an mutat fuisset copiosae, ut elit offendit vel, per alii dolorem suavitate ut. Agam copiosae no quo, te nec vocent insolens deterruisset, everti iuvaret ut mei. Mei at dicat meliore, mel bonorum vocibus fierent te, aliquam elaboraret nec ei. Ea cum libris tibique, mel ei justo virtute delenit. Mea odio case vituperata ei.<br><br>Ad vocent electram imperdiet cum. Integre comprehensam nec cu, natum veniam doming te quo. His in dicant mediocritatem. Cum quem stet zril ea, vel molestie expetenda ea, ea alia utroque sed. Soleat interesset his id. Ad nonumy latine persius mel, te prodesset persecuti inciderint est. Pro pertinacia inciderint neglegentur et.<br><br>Ea pro prompta deserunt, usu elit sadipscing in, dico dolor ei ius. Et mel dicunt diceret lobortis, magna noluisse id ius. Consulatu aliquando quo id, quaeque minimum evertitur et vim, vim vivendum convenire hendrerit id. Vis tamquam labores interesset ut, omnis euismod ocurreret mei et. Sanctus vivendum rationibus ei mei. Purto petentium pro ei, pro ut accusam adipiscing.<br></p>', 1, 3, 0, 0, 0, 1, '2018-03-01 21:42:10', '2018-03-01 21:44:57'),
(17, 'Do  you call your manager 2?', '<p>Ea mei mutat debet solet. Ei utinam voluptatibus mei, amet qualisque vix ex. Nibh feugait cu nam, id per aliquando forensibus. Ex consequat vituperata duo. Ut vim quem quot, detraxit interpretaris duo ad. Mei dolores pertinax delicatissimi eu, eu sit esse ubique salutandi. Ea his vero veri.<br><br>Eum an mutat fuisset copiosae, ut elit offendit vel, per alii dolorem suavitate ut. Agam copiosae no quo, te nec vocent insolens deterruisset, everti iuvaret ut mei. Mei at dicat meliore, mel bonorum vocibus fierent te, aliquam elaboraret nec ei. Ea cum libris tibique, mel ei justo virtute delenit. Mea odio case vituperata ei.<br><br>Ad vocent electram imperdiet cum. Integre comprehensam nec cu, natum veniam doming te quo. His in dicant mediocritatem. Cum quem stet zril ea, vel molestie expetenda ea, ea alia utroque sed. Soleat interesset his id. Ad nonumy latine persius mel, te prodesset persecuti inciderint est. Pro pertinacia inciderint neglegentur et.<br><br>Ea pro prompta deserunt, usu elit sadipscing in, dico dolor ei ius. Et mel dicunt diceret lobortis, magna noluisse id ius. Consulatu aliquando quo id, quaeque minimum evertitur et vim, vim vivendum convenire hendrerit id. Vis tamquam labores interesset ut, omnis euismod ocurreret mei et. Sanctus vivendum rationibus ei mei. Purto petentium pro ei, pro ut accusam adipiscing.<br></p>', 1, 3, 0, 0, 0, 0, '2018-03-01 21:42:38', '2018-03-01 21:42:38'),
(18, 'Do you call your manager 3?', '<p>Ea mei mutat debet solet. Ei utinam voluptatibus mei, amet qualisque vix ex. Nibh feugait cu nam, id per aliquando forensibus. Ex consequat vituperata duo. Ut vim quem quot, detraxit interpretaris duo ad. Mei dolores pertinax delicatissimi eu, eu sit esse ubique salutandi. Ea his vero veri.<br><br>Eum an mutat fuisset copiosae, ut elit offendit vel, per alii dolorem suavitate ut. Agam copiosae no quo, te nec vocent insolens deterruisset, everti iuvaret ut mei. Mei at dicat meliore, mel bonorum vocibus fierent te, aliquam elaboraret nec ei. Ea cum libris tibique, mel ei justo virtute delenit. Mea odio case vituperata ei.<br><br>Ad vocent electram imperdiet cum. Integre comprehensam nec cu, natum veniam doming te quo. His in dicant mediocritatem. Cum quem stet zril ea, vel molestie expetenda ea, ea alia utroque sed. Soleat interesset his id. Ad nonumy latine persius mel, te prodesset persecuti inciderint est. Pro pertinacia inciderint neglegentur et.<br><br>Ea pro prompta deserunt, usu elit sadipscing in, dico dolor ei ius. Et mel dicunt diceret lobortis, magna noluisse id ius. Consulatu aliquando quo id, quaeque minimum evertitur et vim, vim vivendum convenire hendrerit id. Vis tamquam labores interesset ut, omnis euismod ocurreret mei et. Sanctus vivendum rationibus ei mei. Purto petentium pro ei, pro ut accusam adipiscing.<br></p>', 1, 3, 0, 0, 0, 0, '2018-03-01 21:42:57', '2018-03-01 21:42:57'),
(19, 'Do you call your manager 4?', '<p>Ea mei mutat debet solet. Ei utinam voluptatibus mei, amet qualisque vix ex. Nibh feugait cu nam, id per aliquando forensibus. Ex consequat vituperata duo. Ut vim quem quot, detraxit interpretaris duo ad. Mei dolores pertinax delicatissimi eu, eu sit esse ubique salutandi. Ea his vero veri.<br><br>Eum an mutat fuisset copiosae, ut elit offendit vel, per alii dolorem suavitate ut. Agam copiosae no quo, te nec vocent insolens deterruisset, everti iuvaret ut mei. Mei at dicat meliore, mel bonorum vocibus fierent te, aliquam elaboraret nec ei. Ea cum libris tibique, mel ei justo virtute delenit. Mea odio case vituperata ei.<br><br>Ad vocent electram imperdiet cum. Integre comprehensam nec cu, natum veniam doming te quo. His in dicant mediocritatem. Cum quem stet zril ea, vel molestie expetenda ea, ea alia utroque sed. Soleat interesset his id. Ad nonumy latine persius mel, te prodesset persecuti inciderint est. Pro pertinacia inciderint neglegentur et.<br><br>Ea pro prompta deserunt, usu elit sadipscing in, dico dolor ei ius. Et mel dicunt diceret lobortis, magna noluisse id ius. Consulatu aliquando quo id, quaeque minimum evertitur et vim, vim vivendum convenire hendrerit id. Vis tamquam labores interesset ut, omnis euismod ocurreret mei et. Sanctus vivendum rationibus ei mei. Purto petentium pro ei, pro ut accusam adipiscing.<br></p>', 1, 3, 0, 0, 0, 0, '2018-03-01 21:43:12', '2018-03-01 21:43:12'),
(20, 'why do you contact with you manager 2?', '<p>Ea mei mutat debet solet. Ei utinam voluptatibus mei, amet qualisque vix ex. Nibh feugait cu nam, id per aliquando forensibus. Ex consequat vituperata duo. Ut vim quem quot, detraxit interpretaris duo ad. Mei dolores pertinax delicatissimi eu, eu sit esse ubique salutandi. Ea his vero veri.<br><br>Eum an mutat fuisset copiosae, ut elit offendit vel, per alii dolorem suavitate ut. Agam copiosae no quo, te nec vocent insolens deterruisset, everti iuvaret ut mei. Mei at dicat meliore, mel bonorum vocibus fierent te, aliquam elaboraret nec ei. Ea cum libris tibique, mel ei justo virtute delenit. Mea odio case vituperata ei.<br><br>Ad vocent electram imperdiet cum. Integre comprehensam nec cu, natum veniam doming te quo. His in dicant mediocritatem. Cum quem stet zril ea, vel molestie expetenda ea, ea alia utroque sed. Soleat interesset his id. Ad nonumy latine persius mel, te prodesset persecuti inciderint est. Pro pertinacia inciderint neglegentur et.<br><br>Ea pro prompta deserunt, usu elit sadipscing in, dico dolor ei ius. Et mel dicunt diceret lobortis, magna noluisse id ius. Consulatu aliquando quo id, quaeque minimum evertitur et vim, vim vivendum convenire hendrerit id. Vis tamquam labores interesset ut, omnis euismod ocurreret mei et. Sanctus vivendum rationibus ei mei. Purto petentium pro ei, pro ut accusam adipiscing.<br></p>', 1, 3, 0, 0, 0, 0, '2018-03-01 21:43:39', '2018-03-01 21:43:39'),
(21, 'why do you contact with you manager 3?', '<p>Ea mei mutat debet solet. Ei utinam voluptatibus mei, amet qualisque vix ex. Nibh feugait cu nam, id per aliquando forensibus. Ex consequat vituperata duo. Ut vim quem quot, detraxit interpretaris duo ad. Mei dolores pertinax delicatissimi eu, eu sit esse ubique salutandi. Ea his vero veri.<br><br>Eum an mutat fuisset copiosae, ut elit offendit vel, per alii dolorem suavitate ut. Agam copiosae no quo, te nec vocent insolens deterruisset, everti iuvaret ut mei. Mei at dicat meliore, mel bonorum vocibus fierent te, aliquam elaboraret nec ei. Ea cum libris tibique, mel ei justo virtute delenit. Mea odio case vituperata ei.<br><br>Ad vocent electram imperdiet cum. Integre comprehensam nec cu, natum veniam doming te quo. His in dicant mediocritatem. Cum quem stet zril ea, vel molestie expetenda ea, ea alia utroque sed. Soleat interesset his id. Ad nonumy latine persius mel, te prodesset persecuti inciderint est. Pro pertinacia inciderint neglegentur et.<br><br>Ea pro prompta deserunt, usu elit sadipscing in, dico dolor ei ius. Et mel dicunt diceret lobortis, magna noluisse id ius. Consulatu aliquando quo id, quaeque minimum evertitur et vim, vim vivendum convenire hendrerit id. Vis tamquam labores interesset ut, omnis euismod ocurreret mei et. Sanctus vivendum rationibus ei mei. Purto petentium pro ei, pro ut accusam adipiscing.<br></p>', 1, 3, 0, 0, 0, 1, '2018-03-01 21:44:03', '2018-03-01 23:31:58');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(26, '2017_12_21_041854_create_categories_table', 1),
(55, '2010_12_29_025812_create_roletypes_table', 2),
(56, '2010_12_29_025947_create_roles_table', 2),
(57, '2014_10_11_042406_create_regions_table', 2),
(58, '2014_10_12_000000_create_users_table', 2),
(59, '2014_10_12_100000_create_password_resets_table', 2),
(60, '2017_12_21_041853_create_giftcategories_table', 2),
(61, '2017_12_21_041854_create_productcategories_table', 2),
(62, '2017_12_21_042555_create_messages_table', 2),
(63, '2017_12_21_051101_create_leads_table', 2),
(64, '2017_12_21_063650_create_evaluations_table', 2),
(65, '2017_12_21_070436_create_assignments_table', 2),
(66, '2017_12_21_071945_create_statuses_table', 2),
(67, '2017_12_21_072333_create_leadprocesses_table', 2),
(68, '2017_12_21_072804_create_actions_table', 2),
(69, '2017_12_21_072805_create_menus_table', 2),
(70, '2017_12_21_072805_create_permissions_table', 2),
(71, '2017_12_21_073609_create_role_permissions_table', 2),
(72, '2017_12_21_075408_create_gifts_table', 2),
(73, '2017_12_21_080118_create_orders_table', 2),
(74, '2017_12_21_080257_create_order_gifts_table', 2),
(75, '2017_12_21_093715_create_products_table', 2),
(76, '2017_12_21_094349_create_pages_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(10) UNSIGNED NOT NULL,
  `tipster_id` int(10) UNSIGNED NOT NULL,
  `total` decimal(3,0) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_gifts`
--

CREATE TABLE `order_gifts` (
  `id` int(10) UNSIGNED NOT NULL,
  `order_id` int(10) UNSIGNED NOT NULL,
  `gift_id` int(10) UNSIGNED NOT NULL,
  `quality` decimal(8,0) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `published` tinyint(1) NOT NULL,
  `parents` decimal(2,0) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `menu_id` int(10) UNSIGNED NOT NULL,
  `action_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `point_histories`
--

CREATE TABLE `point_histories` (
  `id` int(10) UNSIGNED NOT NULL,
  `tipster_id` int(10) UNSIGNED NOT NULL,
  `lead_id` int(10) UNSIGNED NOT NULL,
  `point` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `point_histories`
--

INSERT INTO `point_histories` (`id`, `tipster_id`, `lead_id`, `point`, `created_at`, `updated_at`) VALUES
(13, 5, 11, 300, '2018-02-02 00:18:18', '2018-02-02 00:18:18'),
(14, 5, 9, 350, '2018-02-02 00:19:06', '2018-02-02 00:19:24'),
(15, 4, 6, 600, '2018-02-02 00:20:48', '2018-02-02 00:20:48'),
(16, 3, 21, 50, '2018-02-07 00:37:15', '2018-02-07 00:37:15'),
(17, 5, 27, 150, '2018-02-07 04:26:49', '2018-02-07 04:26:49'),
(18, 3, 23, 200, '2018-02-07 04:30:10', '2018-02-07 04:30:10'),
(19, 11, 29, 50, '2018-02-08 00:07:24', '2018-02-08 00:07:24'),
(20, 11, 28, 55, '2018-02-08 00:09:43', '2018-02-08 00:09:43'),
(21, 2, 20, 115, '2018-02-08 00:18:41', '2018-02-08 00:18:41'),
(22, 5, 32, 25, '2018-02-08 00:42:52', '2018-02-08 00:42:52'),
(23, 12, 31, 120, '2018-02-08 00:50:55', '2018-02-08 00:50:55');

-- --------------------------------------------------------

--
-- Table structure for table `productcategories`
--

CREATE TABLE `productcategories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `productcategories`
--

INSERT INTO `productcategories` (`id`, `name`, `code`, `description`, `created_at`, `updated_at`) VALUES
(5, 'Insurance', 'insurance', NULL, '2018-01-16 21:24:43', '2018-01-16 21:24:43'),
(6, 'test', 'test', NULL, '2018-01-26 04:21:02', '2018-01-26 04:21:02'),
(8, 'test2', 'test2', NULL, '2018-01-26 04:24:02', '2018-01-26 04:24:02'),
(9, 'test3', 'test3', NULL, '2018-01-26 04:25:57', '2018-01-26 04:25:57'),
(10, 'test4', 'test4', NULL, '2018-01-26 04:26:04', '2018-01-26 04:26:04'),
(13, 'Test 30', 'test30', NULL, '2018-01-26 04:33:46', '2018-01-26 04:33:46'),
(14, 'insu', 'insu', NULL, '2018-01-26 04:35:14', '2018-01-26 04:35:14'),
(15, 'insuu', 'insuu', NULL, '2018-01-26 04:36:01', '2018-01-26 04:36:01'),
(17, 'insuuu', 'insuuu', NULL, '2018-01-26 04:36:23', '2018-01-26 04:36:23'),
(21, 'insuuuuu', 'insuuuuu', NULL, '2018-01-26 04:41:56', '2018-01-26 04:41:56'),
(23, 'insuuuuuuu', 'insuuuuuuu', NULL, '2018-01-26 04:42:23', '2018-01-26 04:42:23'),
(25, 'insu1', 'insu1', NULL, '2018-01-26 04:43:32', '2018-01-26 04:43:32'),
(26, 'insur', 'insur', NULL, '2018-01-26 04:44:18', '2018-01-26 04:44:18'),
(28, 'insurr', 'insurr', NULL, '2018-01-26 04:45:29', '2018-01-26 04:45:29'),
(37, 'electroni', 'electroni', NULL, '2018-01-26 04:55:38', '2018-01-26 04:55:38'),
(38, 'gift', 'gift', NULL, '2018-01-26 04:56:29', '2018-01-26 04:56:29'),
(40, 'uuuuuuuuuuuuuuuuuu', 'uuuuuuuuuuuuuuuuuu', NULL, '2018-02-13 00:29:51', '2018-02-13 00:29:51'),
(41, 'wwwwwwwwwwwwwwwww', 'wwwwwwwwwwwwwwwww', NULL, '2018-02-13 00:31:30', '2018-02-13 00:31:30'),
(43, 'tttttttttttt', 'tttttttttttt', NULL, '2018-02-13 00:31:44', '2018-02-13 00:31:44'),
(45, 'tttttttttdasda', 'tttttttttdasda', NULL, '2018-02-13 02:20:48', '2018-02-13 02:20:48');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `price` decimal(8,0) NOT NULL DEFAULT '0',
  `thumbnail` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quality` decimal(8,0) NOT NULL DEFAULT '0',
  `category_id` int(10) UNSIGNED NOT NULL,
  `delete_is` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `thumbnail`, `quality`, `category_id`, `delete_is`, `created_at`, `updated_at`) VALUES
(4, 'Medical', 'Id solum dolore cum, ex pri modus cotidieque, id rebum theophrastus mel. Cu eam modus laoreet pericula, mundi repudiare pro in. Cu agam mucius delicata per, nec ad possim philosophia. Id brute liber oporteat usu.\r\n\r\nNec ea quod doctus splendide, vide homero ius ad. Cu dicat populo eam. Ei urbanitas ullamcorper sed, mei cu atomorum reprehendunt. Nostro admodum maiestatis eum ea, illum eligendi partiendo pro cu. Tantas ornatus efficiendi eu vis, ei eum eligendi definitiones. Viris impetus sit cu, alia albucius has ut.\r\n\r\nEu sea fabellas intellegam, eum id altera facilisi moderatius. Ea duo diam persequeris, ea agam menandri est. Has velit liberavisse in. Ei illud voluptaria quaerendum eos, primis appellantur ut vix. Wisi doming eum no.', '0', '1519638566.jpg', '0', 5, 0, NULL, '2018-02-26 02:49:36'),
(5, 'Auto/Moto', '', '0', NULL, '0', 5, 0, NULL, NULL),
(6, 'Shops', '', '0', NULL, '0', 5, 1, NULL, '2018-02-28 21:29:54'),
(7, 'Factory', '', '0', NULL, '0', 5, 0, NULL, NULL),
(8, 'Office', '', '0', NULL, '0', 5, 0, NULL, NULL),
(9, 'Home', '', '0', NULL, '0', 5, 0, NULL, NULL),
(10, 'Travel', '', '0', NULL, '0', 5, 0, NULL, NULL),
(11, 'Student', '', '0', NULL, '0', 5, 0, NULL, NULL),
(12, 'Other', '', '0', NULL, '0', 5, 0, NULL, NULL),
(13, 'test', 'dias hdsjd', '0', 'no_image_available.jpg', '0', 13, 1, '2018-02-28 20:12:20', '2018-02-28 21:11:58'),
(14, 'Shop', NULL, '0', '1519879925.png', '0', 5, 0, '2018-02-28 21:51:44', '2018-02-28 21:52:08');

-- --------------------------------------------------------

--
-- Table structure for table `regions`
--

CREATE TABLE `regions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `regions`
--

INSERT INTO `regions` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Ha Noi', NULL, NULL),
(2, 'Ho Chi Minh', NULL, NULL),
(3, 'Da Nang', NULL, NULL),
(4, 'Nha Trang', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roletype_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `code`, `roletype_id`) VALUES
(1, 'Admin', 'admin', 1),
(2, 'Community', 'community', 1),
(3, 'Sale', 'sale', 1),
(4, 'Insurance', 'insurance', 2),
(5, 'Car', 'car', 2),
(6, 'Real estate', 'realestate', 2),
(7, 'Service', 'service', 2),
(8, 'Ambassador', 'ambassador', 3),
(9, 'Tipster', 'tipster_normal', 3);

-- --------------------------------------------------------

--
-- Table structure for table `roletypes`
--

CREATE TABLE `roletypes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roletypes`
--

INSERT INTO `roletypes` (`id`, `name`, `code`) VALUES
(1, 'Manager', 'manager'),
(2, 'Consultant', 'consultant'),
(3, 'Tipster', 'tipster');

-- --------------------------------------------------------

--
-- Table structure for table `role_permissions`
--

CREATE TABLE `role_permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `permission_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `statuses`
--

CREATE TABLE `statuses` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fullname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` tinyint(4) NOT NULL,
  `birthday` date NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `point` decimal(8,0) NOT NULL DEFAULT '0',
  `vote` decimal(4,0) NOT NULL DEFAULT '0',
  `delete_is` tinyint(4) NOT NULL DEFAULT '0',
  `role_id` int(10) UNSIGNED NOT NULL,
  `region_id` int(10) UNSIGNED NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `fullname`, `avatar`, `gender`, `birthday`, `address`, `phone`, `point`, `vote`, `delete_is`, `role_id`, `region_id`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@amagumolabs.com', '$2y$10$8q2YeXKpiQGxqffDUeCaauNwPoQqnN7CmPy6HxXeRP7d5JF6nvToG', 'Admin', '1518494432.png', 1, '2017-12-12', 'Ho Chi Minh, Viet Nam', '093893771', '0', '0', 0, 1, 1, 'S3iwkM5KNtsnOC2gXBBuJAVhZPRP2VlqumMEBoVL8dceWQwSYB3zErr2AmXZ', NULL, '2018-02-12 21:00:34'),
(2, 'tipster1', 'tipster1@gmail.com', '$2y$10$umRwAmT3NST33aLjGySLgOXmRD7aHm1/K0YEBDMJrFey0H0TsTPMy', 'Nguyễn Hà Mỹ Ngọc', '1519972130.png', 1, '1990-12-20', 'Tan Binh', '01928739831', '115', '0', 0, 8, 2, 'SXvLpMDWtTngbJoEy6MUsUgaq04MbYcG0F54Mup5Pv8m9FOkCvvHvhvk8ghq', '2018-01-16 22:17:29', '2018-03-01 23:28:54'),
(3, 'tipster2', 'tipster2@gmail.com', '$2y$10$VYctWG6DoE4Mf3zqLLzwGu6RDxT8/DdriDS94ol0.iKsHcOtShOGm', 'Nguyễn Phạm Duy Hậu', 'user6-128x128.jpg', 0, '1982-01-11', 'Hoan Kiem', '0989310732', '250', '0', 1, 9, 1, 'WuihkcHAd4wYGKyVBjwDX0s7H9zicfeNmItNaalJiAsPUu4yrDn9qXLkS3TV', '2018-01-17 20:38:44', '2018-02-07 04:30:10'),
(4, 'tipster3', 'tipster3@gmail.com', '$2y$10$FkYTVllLc60zli2MSwbg3u/miVmdPqsxWA12AM6v8GwAfJOuOAIIq', 'Phạm Trần Bảo Duy', 'user8-128x128.jpg', 1, '1981-01-19', 'Tran Hung Dao', '0989310981', '600', '0', 1, 9, 3, 'yx8vFSBMXXzWPNdP3qOyJHE4mzn7WQbqmCxtcujgN5fw38eyGSZaBb3nM3k5', '2018-01-17 20:40:37', '2018-02-06 00:43:56'),
(5, 'tipster4', 'tipster4@gmail.com', '$2y$10$PQUkjmW4GTPhfRU4.qMY1eF4z5klCeh29CrPMqURPCMmZPM8pVA/K', 'Trần Đại Nhân Nghĩa', 'user5-128x128.jpg', 0, '1992-01-20', 'Nguyen Chi Thanh', '0888172361', '825', '0', 1, 9, 4, NULL, '2018-01-17 20:42:36', '2018-02-08 00:42:52'),
(6, 'consultant1', 'consultant@gmail.com', '$2y$10$v1rQG22BYwgETQhb3s6ROu6mRK2V2qd5p6wDFmec1xls0RybQ.xbi', 'Consultant Thuy', '1519813762.jpg', 1, '2000-01-10', 'Hai Ba Trung', '019876518', '0', '0', 0, 5, 2, '3TlN8eDo5nyQUl0EXG1LkJFQqmMc695pHKybPdztsB2RVMvyrroJYXv29pnZ', '2018-01-18 01:04:05', '2018-02-28 03:29:27'),
(7, 'hachit', 'chitha@gmail.com', '$2y$10$9JU56BB/CPq2YtepwRtjOOb6XtsPUdd4b7tQwJn57ZHkrSSgvLqM6', 'Ha Chi T', '1519811640.png', 0, '1980-01-12', 'Son Tra', '09897682721', '0', '0', 1, 6, 3, NULL, '2018-01-22 00:02:30', '2018-03-01 19:41:11'),
(8, 'salemanager', 'salemanager@gmail.com', '$2y$10$Hl8HdrjLhvAmDxDflz38POqbcd4Y.4fncNf2d0BFTjCU.m0tmOtdy', 'Sale Manager', '1519812636.jpg', 0, '1998-12-04', 'Hai Ba Trung', '0981237823', '0', '0', 0, 3, 2, 'cp6UgbprGJh39Fg2DjS98seqVkPoUjzYcvPstlwvju2LvdoqJFzOk7KOPRou', '2018-01-22 01:09:20', '2018-03-01 19:39:14'),
(9, 'community', 'communityman@gmail.com', '$2y$10$akhhKTnJ2ANdoW5OSy9rpuwRQoi/FMls4nGD7rYJ0Ekxv.74jeaE6', 'Community Manager', '1518494280.png', 1, '1987-03-21', 'Dong Den', '0998987721', '0', '0', 0, 2, 2, 'RkPCvMQk5III3IPO8EU0iVuU4byjJNQuvLlB5Jfe2EI9XTnTwPRmC8gLPDp7', '2018-01-22 01:11:00', '2018-03-01 19:39:06'),
(10, 'quanghbui', 'quanghbui@gmail.com', '$2y$10$E3B6V5V/0tuaCcxRX4VlMOeif8vF373kg59/HmbYhblQgWb6UN3TO', 'Bui Quang H', '1518495037.png', 0, '1997-01-10', '11', '1231234123', '0', '0', 0, 4, 1, 'KvjbGZ9cYI8rcLBWznUJcRXmc6DrXBK6ejhVW7AVpWxGaofruwvhvTnSQTdA', '2018-01-24 01:17:00', '2018-03-01 19:39:26'),
(11, 'phamdangthuy2310', 'phamdangthuy2310@yahoo.com', '$2y$10$/eGFFoabHTyjMp/XDXPVSOrcVD9Kw4ovF1kOFZT8GtWCQowUaD1Ua', 'Phạm Thị Đang Thùy', 'user4-128x128.jpg', 1, '1990-01-12', 'Tân Bình Hồ Chí Minh', '09887165532', '105', '0', 1, 9, 2, NULL, '2018-01-31 01:46:19', '2018-02-08 00:09:43'),
(12, 'tipster5', 'chathien@gmail.com', '$2y$10$tY4SGfEx.E3CA/S89Dy3Ful2QR00eVeT8CyRxmtoKiPkE5mJ9t0g.', 'Nguyễn Chất Hiển', '1518406811.jpg', 0, '1990-02-14', 'Quận 12', '0988127386', '120', '0', 1, 9, 2, NULL, '2018-02-06 05:19:20', '2018-02-11 20:40:15'),
(13, 'tipster6', 'huongdinh@gmail.com', '$2y$10$DOterjtF8olO47ese595TOEglm1a0VyL9JENeC.2cX8euCN92LIsK', 'Đinh Văn Hưởng', NULL, 0, '1989-02-15', 'Tan Phu', '0982977661', '0', '0', 1, 9, 2, NULL, '2018-02-06 05:23:58', '2018-02-06 05:23:58'),
(14, 'tipster7', 'sangnguyen@gmail.com', '$2y$10$TFIYR8Q2zB408MhAG8nQgeFY5a/fCdDBHXsouAF9pZN3Z6hP1zNXm', 'Nguyễn Thanh Sang', NULL, 0, '1991-02-10', 'Quận 9', '019293897231', '0', '0', 1, 9, 2, NULL, '2018-02-06 05:25:38', '2018-02-06 05:31:04'),
(15, 'tipster8', 'laibich@gmail.com', '$2y$10$T2WqjNWmCkNFj4MWzrjQ0.pTtM0WK7VzgXHnTYu.J.rLtuoq5/p8a', 'Trần Thị Bích Lài', NULL, 1, '1990-04-12', 'Hóc Môn', '039128372', '0', '0', 1, 9, 2, NULL, '2018-02-06 05:34:36', '2018-02-08 21:21:44'),
(16, 'tuyetminh', 'tuyetminh@gmail.com', '$2y$10$z5tdnxuT720WTht4949WXuOHlhJI8LTxXdNy/d0rEqkDBwqt5fQVu', 'Phạm Thị Minh Tuyết', NULL, 1, '1992-02-15', 'Tân Phú', '0987667872', '0', '0', 1, 9, 2, NULL, '2018-02-06 06:03:33', '2018-02-08 20:31:03'),
(17, 'khackhoan', 'khackhoan@gmail.com', '$2y$10$c3M6U64EL0zsKfFxoaIEoOVG43gUKlJgJfYyqwYepS95GzRi99b7y', 'Phùng Khắc Khoan', '1518494915.png', 0, '1955-02-13', 'Quận 3', '0381907896', '0', '0', 0, 3, 2, NULL, '2018-02-09 00:12:42', '2018-03-01 19:39:20'),
(18, 'haanh', 'haanh@gmail.com', '$2y$10$VFqQyzAzDaY3IKPeQQO87uXFwLVxR8tckrzQMOgPxF2kJfs1fFxem', 'Nguyễn Hà Anh', '1518176368.png', 1, '1990-02-13', 'Bát Tràng', '099091897', '0', '0', 1, 9, 1, NULL, '2018-02-09 00:33:47', '2018-02-09 04:39:34'),
(19, 'btranhao', 'haob@gmail.com', '$2y$10$YDuzbkUhNyb9Dd0Pz/Bj9uAiQZ9CwEycoXpn68ynuizoO47xL6Kui', 'Trần Hòa B', '1518176995.png', 0, '1992-02-06', 'Điện Biên Phủ', '093018093', '0', '0', 1, 9, 3, NULL, '2018-02-09 04:51:52', '2018-02-09 04:51:52');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `actions`
--
ALTER TABLE `actions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `actions_code_unique` (`code`);

--
-- Indexes for table `assignments`
--
ALTER TABLE `assignments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `evaluationautos`
--
ALTER TABLE `evaluationautos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `giftcategories`
--
ALTER TABLE `giftcategories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `giftcategories_code_unique` (`code`);

--
-- Indexes for table `gifts`
--
ALTER TABLE `gifts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `gifts_category_id_foreign` (`category_id`);

--
-- Indexes for table `leadprocesses`
--
ALTER TABLE `leadprocesses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `leadprocesses_lead_id_foreign` (`lead_id`),
  ADD KEY `leadprocesses_status_id_foreign` (`status_id`);

--
-- Indexes for table `leads`
--
ALTER TABLE `leads`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `leads_email_unique` (`email`),
  ADD KEY `leads_tipster_id_foreign` (`tipster_id`),
  ADD KEY `leads_region_id_foreign` (`region_id`);

--
-- Indexes for table `log_activities`
--
ALTER TABLE `log_activities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `menus_code_unique` (`code`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_tipster_id_foreign` (`tipster_id`);

--
-- Indexes for table `order_gifts`
--
ALTER TABLE `order_gifts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_gifts_order_id_foreign` (`order_id`),
  ADD KEY `order_gifts_gift_id_foreign` (`gift_id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_code_unique` (`code`),
  ADD KEY `permissions_action_id_foreign` (`action_id`),
  ADD KEY `permissions_menu_id_foreign` (`menu_id`);

--
-- Indexes for table `point_histories`
--
ALTER TABLE `point_histories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `productcategories`
--
ALTER TABLE `productcategories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `productcategories_code_unique` (`code`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_category_id_foreign` (`category_id`);

--
-- Indexes for table `regions`
--
ALTER TABLE `regions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `regions_name_unique` (`name`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_code_unique` (`code`),
  ADD KEY `roles_roletype_id_foreign` (`roletype_id`);

--
-- Indexes for table `roletypes`
--
ALTER TABLE `roletypes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_permissions_role_id_foreign` (`role_id`),
  ADD KEY `role_permissions_permission_id_foreign` (`permission_id`);

--
-- Indexes for table `statuses`
--
ALTER TABLE `statuses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `statuses_name_unique` (`name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_role_id_foreign` (`role_id`),
  ADD KEY `users_region_id_foreign` (`region_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `actions`
--
ALTER TABLE `actions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `assignments`
--
ALTER TABLE `assignments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `evaluationautos`
--
ALTER TABLE `evaluationautos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `giftcategories`
--
ALTER TABLE `giftcategories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `gifts`
--
ALTER TABLE `gifts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `leadprocesses`
--
ALTER TABLE `leadprocesses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `leads`
--
ALTER TABLE `leads`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `log_activities`
--
ALTER TABLE `log_activities`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=114;

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_gifts`
--
ALTER TABLE `order_gifts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `point_histories`
--
ALTER TABLE `point_histories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `productcategories`
--
ALTER TABLE `productcategories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `regions`
--
ALTER TABLE `regions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `roletypes`
--
ALTER TABLE `roletypes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `role_permissions`
--
ALTER TABLE `role_permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `statuses`
--
ALTER TABLE `statuses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `gifts`
--
ALTER TABLE `gifts`
  ADD CONSTRAINT `gifts_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `giftcategories` (`id`);

--
-- Constraints for table `leads`
--
ALTER TABLE `leads`
  ADD CONSTRAINT `leads_region_id_foreign` FOREIGN KEY (`region_id`) REFERENCES `regions` (`id`),
  ADD CONSTRAINT `leads_tipster_id_foreign` FOREIGN KEY (`tipster_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_tipster_id_foreign` FOREIGN KEY (`tipster_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `order_gifts`
--
ALTER TABLE `order_gifts`
  ADD CONSTRAINT `order_gifts_gift_id_foreign` FOREIGN KEY (`gift_id`) REFERENCES `gifts` (`id`),
  ADD CONSTRAINT `order_gifts_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`);

--
-- Constraints for table `permissions`
--
ALTER TABLE `permissions`
  ADD CONSTRAINT `permissions_action_id_foreign` FOREIGN KEY (`action_id`) REFERENCES `actions` (`id`),
  ADD CONSTRAINT `permissions_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `productcategories` (`id`);

--
-- Constraints for table `roles`
--
ALTER TABLE `roles`
  ADD CONSTRAINT `roles_roletype_id_foreign` FOREIGN KEY (`roletype_id`) REFERENCES `roletypes` (`id`);

--
-- Constraints for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD CONSTRAINT `role_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`),
  ADD CONSTRAINT `role_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_region_id_foreign` FOREIGN KEY (`region_id`) REFERENCES `regions` (`id`),
  ADD CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
