@extends('layouts.master')
@section('title', 'Create Lead')

@section('content')
    index
@endsection