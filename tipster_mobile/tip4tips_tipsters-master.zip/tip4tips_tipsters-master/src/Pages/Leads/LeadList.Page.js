import React, { Component } from 'react';
 import LeadListContainer from '../../Containers/Leads/LeadList.Container';

export default class LeadListPage extends Component {
    render() {
        return (
            <LeadListContainer/>
        );
    }
}