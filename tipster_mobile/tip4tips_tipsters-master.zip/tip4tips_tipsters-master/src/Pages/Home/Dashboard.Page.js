import React, { Component } from 'react';
import DashboardContainer from '../../Containers/Home/Dashboard.Container';

export default class Dashboard extends Component {
    render() {
        return (
            <DashboardContainer/>
        );
    }
}