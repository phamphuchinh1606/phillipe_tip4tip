import React, { Component } from 'react';
 import MessageContainer from '../../Containers/Messages/Messages.Container';

export default class MessagesPage extends Component {
    render() {
        return (
            <MessageContainer/>
        );
    }
}