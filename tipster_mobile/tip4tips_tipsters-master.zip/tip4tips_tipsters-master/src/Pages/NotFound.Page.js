import React, { Component } from 'react';


export default class NotFound extends Component {
  render() {
    return (
        <h1>Not found this page</h1>
    );
  }
}